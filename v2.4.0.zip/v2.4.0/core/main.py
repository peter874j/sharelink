 # -*- coding: utf-8 -*-
"""
Created on Mon Dec  5 13:18:08 2022

@author: User
"""

import os
import sys
import cv2
import time
import threading

import numpy as np
import pandas as pd
from pypylon import pylon, genicam

import PySide2
from PySide2 import QtCore, QtGui, QtWidgets

from PySide2.QtCore import *
from PySide2.QtCore import (
    Qt,
    QRect,
    QPoint,
    QObject,
    QThread,
    QTimer,
    QDateTime,
    Signal,
    Slot,
    QCoreApplication,
    QEvent,
)

from PySide2.QtGui import *
from PySide2.QtGui import QPixmap, QImage, QPainter, QPen, QGuiApplication, QFont, QColor, QMouseEvent

from PySide2.QtWidgets import *
from PySide2.QtWidgets import QMainWindow, QApplication, QWidget, QLabel, QTableWidgetItem, QMessageBox

from gui.MainUI import Ui_MainWindow

from gui.App import App
from utils.Camera import Camera, CamMutual

class MainWindow(QtWidgets.QMainWindow):
    def __init__(self):
        super(MainWindow, self).__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.setWindowFlags(Qt.WindowCloseButtonHint)

        self.init_ui()

        self.flag_printer = 0  # 噴墨訊號

        # """ 連接相機並輸出視訊 """
        self.cap = Mutual.camDict
        self.deviceNumber = Mutual.deviceNumberDict
        self.timer_camera = QTimer()
        self.timer_camera.timeout.connect(self.show_camera)
        self.timer_camera.start(1)

    def init_ui(self):
        self.ui.label_logo.setPixmap(QtGui.QPixmap("auo.jpg"))
        self.ui.label_logo.setScaledContents(True)

        self.ui.Btn_Printer.clicked.connect(self.printer_set)
        self.ui.Btn_Printer.setCheckable(True)

        self.app = App()
        self.ui.Btn_Check.clicked.connect(self.app.new_func)
        self.ui.Btn_Check.clicked.connect(self.app.show)

        """ 顯示本機時間 """
        self.timer = QTimer()
        self.timer.timeout.connect(self.showtime)
        self.timer.start(1000)

    def showtime(self):
        """顯示系統時間"""
        self.now_time = QDateTime.currentDateTime()  # 獲取當前時間
        timedisplay = self.now_time.toString("yyyy-MM-dd hh:mm:ss")  # 格式化時間
        self.ui.label_time.setText(timedisplay)

    def show_camera(self):
        """顯示webcam畫面"""
        len_cap = len(self.cap)
        if len_cap != 0:
            for cam in self.cap:
                try:
                    if CamMutual.severParmDict['mode'] =='camera':
                        if self.deviceNumber[cam] == CamMutual.camParmDict['Top_cam1_deviceNumber']:
                            frame0 = self.cap[cam].get_frame(stream=True, flag_printer = self.flag_printer)
                            frame0 = self.webcam_display(frame0)
                            self.ui.top_cam1.setPixmap(frame0)
                            self.ui.top_cam1.setScaledContents(True)

                        elif self.deviceNumber[cam] == CamMutual.camParmDict['Top_cam2_deviceNumber']:
                            frame1 = self.cap[cam].get_frame(stream=True, flag_printer = self.flag_printer)
                            frame1 = self.webcam_display(frame1)
                            self.ui.top_cam2.setPixmap(frame1)
                            self.ui.top_cam2.setScaledContents(True)

                        elif self.deviceNumber[cam] == CamMutual.camParmDict['Btm_cam1_deviceNumber']:
                            frame2 = self.cap[cam].get_frame(stream=True, flag_printer = self.flag_printer)
                            frame2 = self.webcam_display(frame2)
                            self.ui.btm_cam1.setPixmap(frame2)
                            self.ui.btm_cam1.setScaledContents(True)

                        elif self.deviceNumber[cam] == CamMutual.camParmDict['Btm_cam2_deviceNumber']:
                            frame3 = self.cap[cam].get_frame(stream=True, flag_printer = self.flag_printer)
                            frame3 = self.webcam_display(frame3)
                            self.ui.btm_cam2.setPixmap(frame3)
                            self.ui.btm_cam2.setScaledContents(True)

                    else:
                        ####################  攝影機隨機出現寫法  ##########################################################
                        if cam == 0:
                            frame0 = self.cap[cam].get_frame(stream=True, flag_printer = self.flag_printer)
                            frame0 = self.webcam_display(frame0)
                            self.ui.top_cam1.setPixmap(frame0)
                            self.ui.top_cam1.setScaledContents(True)

                        elif cam == 1:
                            frame1 = self.cap[cam].get_frame(stream=True, flag_printer = self.flag_printer)
                            frame1 = self.webcam_display(frame1)
                            self.ui.top_cam2.setPixmap(frame1)
                            self.ui.top_cam2.setScaledContents(True)

                        elif cam == 2:
                            frame2 = self.cap[cam].get_frame(stream=True, flag_printer = self.flag_printer)
                            frame2 = self.webcam_display(frame2)
                            self.ui.btm_cam1.setPixmap(frame2)
                            self.ui.btm_cam1.setScaledContents(True)

                        elif cam == 3:
                            frame3 = self.cap[cam].get_frame(stream=True, flag_printer = self.flag_printer)
                            frame3 = self.webcam_display(frame3)
                            self.ui.btm_cam2.setPixmap(frame3)
                            self.ui.btm_cam2.setScaledContents(True)

                except:
                    print('show camera error')

    def webcam_display(self, frame):
        """處理OpenCV圖片轉QPixmap"""
        height, width, depth = frame.shape
        frame = cv2.cvtColor(frame, cv2.COLOR_RGB2BGR)
        cvimg = QImage(frame.data, frame.shape[1], frame.shape[0], frame.shape[1] * 3, QImage.Format_RGB888)
        return QPixmap.fromImage(cvimg)

    def printer_set(self, event):
        """噴墨機訊號開關"""
        
        if self.ui.Btn_Printer.isChecked():
            self.ui.Btn_Printer.setStyleSheet("background-color: red;  border-radius: 10px; border: 2px solid gray;")
            self.flag_printer = 1

        else:
            self.ui.Btn_Printer.setStyleSheet("background-color: green; border-radius: 10px; border: 2px solid gray;")
            self.flag_printer = 0

class Mutual:
    camDict = {}
    deviceNumberDict = {}

def run():
    os.environ["PYLON_CAMEMU"] = "4"

    maxCamerasToUse = 4
    tlFactory = pylon.TlFactory.GetInstance()
    devices = tlFactory.EnumerateDevices()

    if len(devices) == 0:
        raise pylon.RuntimeException("No camera present.")

    tlFactory = pylon.TlFactory.GetInstance()
    devices = tlFactory.EnumerateDevices()
    converter = pylon.ImageFormatConverter()
    converter.OutputPixelFormat = pylon.PixelType_BGR8packed
    converter.OutputBitAlignment = pylon.OutputBitAlignment_MsbAligned
    cameras = pylon.InstantCameraArray(min(len(devices), maxCamerasToUse))

    for i in range(maxCamerasToUse):
        camInstance = Camera(devices=devices, tlFactory=tlFactory, converter=converter, cameras=cameras, device=i)
        camInstance.run()
        Mutual.camDict[i] = camInstance
        try:
            Mutual.deviceNumberDict[i] = camInstance.deviceNumber
        except:
            print('example')

    app = QtCore.QCoreApplication.instance()
    if app is None:
        app = QtWidgets.QApplication(sys.argv)
    window = MainWindow()
    window.show()

    app.exec_()
    for camIndex, camInstance in Mutual.camDict.items():
        camInstance.stop()
    os._exit(0)

if __name__ == "__main__":
    run()
