# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'Local_UI.ui'
#
# Created by: PyQt5 UI code generator 5.13.0
#
# WARNING! All changes made in this file will be lost!


from PySide2 import QtCore, QtGui, QtWidgets
from PySide2.QtWidgets import QDesktopWidget


class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        screen = QDesktopWidget().screenGeometry()
        width, height = screen.width(), screen.height()
        MainWindow.resize(width, height)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.gridLayout_2 = QtWidgets.QGridLayout(self.centralwidget)
        self.gridLayout_2.setObjectName("gridLayout_2")
        self.horizontalLayout_2 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_2.setObjectName("horizontalLayout_2")
        
        self.label_logo = QtWidgets.QLabel(self.centralwidget)
        self.label_logo.setObjectName("label_logo")
        self.horizontalLayout_2.addWidget(self.label_logo)
        
        spacerItem = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout_2.addItem(spacerItem)
        self.label_time = QtWidgets.QLabel(self.centralwidget)
        self.label_time.setObjectName("label_time")
        self.horizontalLayout_2.addWidget(self.label_time)
        
        self.horizontalLayout_2.addItem(spacerItem)
        self.label_model = QtWidgets.QLabel(self.centralwidget)
        self.label_model.setObjectName("label_model")
        self.horizontalLayout_2.addWidget(self.label_model)
        
        self.gridLayout_2.addLayout(self.horizontalLayout_2, 0, 0, 1, 1)
        self.horizontalLayout_3 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_3.setObjectName("horizontalLayout_3")

        self.horizontalLayout_3.addItem(spacerItem)
        self.Btn_Printer = QtWidgets.QPushButton(self.centralwidget)
        self.Btn_Printer.setStyleSheet("QPushButton { background-color: green; border-radius: 10px; border: 2px solid gray; }")
        self.Btn_Printer.setMinimumSize(QtCore.QSize(200, 80))
        self.Btn_Printer.setObjectName("Btn_Printer")
        self.horizontalLayout_3.addWidget(self.Btn_Printer)
        self.horizontalLayout_3.addItem(spacerItem)
        self.horizontalLayout_3.addItem(spacerItem)
        self.Btn_Check = QtWidgets.QPushButton(self.centralwidget)
        self.Btn_Check.setStyleSheet("QPushButton { border-radius: 10px; border: 2px solid gray; }")
        self.Btn_Check.setMinimumSize(QtCore.QSize(200, 80))
        self.Btn_Check.setObjectName("Btn_Check")
        self.horizontalLayout_3.addWidget(self.Btn_Check)
        self.horizontalLayout_3.addItem(spacerItem)

        self.gridLayout_2.addLayout(self.horizontalLayout_3, 2, 0, 1, 1)
        self.gridLayout = QtWidgets.QGridLayout()
        self.gridLayout.setSpacing(0)
        self.gridLayout.setObjectName("gridLayout")

        self.top_cam1 = QtWidgets.QLabel(self.centralwidget)
        self.top_cam1.setMinimumSize(QtCore.QSize(300, 300))
        self.top_cam1.setAlignment(QtCore.Qt.AlignCenter)
        self.top_cam1.setObjectName("top_cam1")
        self.gridLayout.addWidget(self.top_cam1, 1, 0, 1, 1)
        self.top_cam2 = QtWidgets.QLabel(self.centralwidget)
        self.top_cam2.setMinimumSize(QtCore.QSize(300, 300))
        self.top_cam2.setAlignment(QtCore.Qt.AlignCenter)
        self.top_cam2.setObjectName("top_cam2")
        self.gridLayout.addWidget(self.top_cam2, 1, 1, 1, 1)

        spacerItem2 = QtWidgets.QSpacerItem(5, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.gridLayout.addItem(spacerItem2, 1, 1, 1, 1)

        self.btm_cam2 = QtWidgets.QLabel(self.centralwidget)
        self.btm_cam2.setMinimumSize(QtCore.QSize(500, 300))
        self.btm_cam2.setAlignment(QtCore.Qt.AlignCenter)
        self.btm_cam2.setObjectName("btm_cam2")
        self.gridLayout.addWidget(self.btm_cam2, 3, 1, 1, 1)
        self.btm_cam1 = QtWidgets.QLabel(self.centralwidget)
        self.btm_cam1.setMinimumSize(QtCore.QSize(500, 300))
        self.btm_cam1.setAlignment(QtCore.Qt.AlignCenter)
        self.btm_cam1.setObjectName("btm_cam1")

        self.gridLayout.addWidget(self.btm_cam1, 3, 0, 1, 1)
        self.title_top_cam1 = QtWidgets.QLabel(self.centralwidget)
        self.title_top_cam1.setObjectName("title_top_cam1")
        self.gridLayout.addWidget(self.title_top_cam1, 0, 0, 1, 1)
        self.title_top_cam2 = QtWidgets.QLabel(self.centralwidget)
        self.title_top_cam2.setObjectName("title_top_cam2")
        self.gridLayout.addWidget(self.title_top_cam2, 0, 1, 1, 1)
        self.title_btm_cam1 = QtWidgets.QLabel(self.centralwidget)
        self.title_btm_cam1.setObjectName("title_btm_cam1")
        self.gridLayout.addWidget(self.title_btm_cam1, 2, 0, 1, 1)
        self.title_btm_cam2 = QtWidgets.QLabel(self.centralwidget)
        self.title_btm_cam2.setObjectName("title_btm_cam2")
        self.gridLayout.addWidget(self.title_btm_cam2, 2, 1, 1, 1)

        self.gridLayout.setColumnStretch(0, 1)
        self.gridLayout.setColumnStretch(1, 1)
        self.gridLayout.setRowStretch(1, 1)
        self.gridLayout.setRowStretch(3, 1)
        self.gridLayout_2.addLayout(self.gridLayout, 1, 0, 1, 1)
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 1052, 21))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.label_logo.setText(_translate("MainWindow", "TextLabel"))
        self.label_time.setText(_translate("MainWindow", "TextLabel"))
        self.label_model.setText(_translate("MainWindow", "TextLabel"))
        self.Btn_Printer.setText(_translate("MainWindow", "噴字機"))
        self.Btn_Check.setText(_translate("MainWindow", "檢查Log"))
        self.top_cam1.setText(_translate("MainWindow", "TextLabel"))
        self.top_cam2.setText(_translate("MainWindow", "TextLabel"))
        self.btm_cam2.setText(_translate("MainWindow", "TextLabel"))
        self.btm_cam1.setText(_translate("MainWindow", "TextLabel"))
        self.title_top_cam1.setText(_translate("MainWindow", "Top Cam1"))
        self.title_top_cam2.setText(_translate("MainWindow", "Top Cam2"))
        self.title_btm_cam1.setText(_translate("MainWindow", "Btm Cam1"))
        self.title_btm_cam2.setText(_translate("MainWindow", "Btm Cam2"))
