import os
import cv2
import numpy as np
from datetime import datetime
from pathlib import Path
import sys
sys.path.append("./")
from utils.FilterBackground import FilterBackground
from utils.FileManager import FileManagement
from utils.GetCfg import ServerPramCfg
import threading

def log(c, img):
    output = c * np.log(1.0 + img)
    output = np.uint8(output + 0.5)
    return output

def gamma(img, c, v):
    lut = np.zeros(256, dtype=np.float32)
    for i in range(256):
        lut[i] = c * i ** v
    output_img = cv2.LUT(img, lut) #像素灰度值的映射
    output_img = np.uint8(output_img+0.5)  
    return output_img

def remove_file(parmDict, pathFolder):
    FM = FileManagement()
    FM.auto_remove_by_date(os.path.join(os.getcwd(), pathFolder), parmDict['maxdays'])
    FM.auto_remove_by_size(os.path.join(os.getcwd(), pathFolder), parmDict['maxmbsize'])

def remove_file_run(parmDict, pathFolder):
    thread = threading.Thread(target = remove_file, args=([parmDict, pathFolder]))
    thread.start()

def save_path(timeNow, parmDict):
    pathFolder  = "log"
    savePath = Path(r".\\").joinpath(pathFolder, timeNow.strftime("%Y%m%d"))
    Path(os.path.join(savePath, 'NG')).mkdir(parents=True, exist_ok=True)
    Path(os.path.join(savePath, 'OK')).mkdir(parents=True, exist_ok=True)
    Path(os.path.join(savePath, 'NG', 'Orig')).mkdir(parents=True, exist_ok=True)
    remove_file_run(parmDict, pathFolder)
    return savePath

def flaw_detect(folder_path, fileName, timeNow, parmDict):
    savePath = save_path(timeNow, parmDict)
    image = cv2.imread('{}/{}'.format(folder_path, fileName))
    imageOrgi = image.copy()
    filterBackground = FilterBackground(image)
    image, points, points_pair= filterBackground.background(parmDict)

    ### 圖像轉灰階
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    # lab = cv2.cvtColor(image, cv2.COLOR_BGR2Lab)
    result = image.copy()
    grayPoint =  gray[gray!=0]
    grayMax = grayPoint.max()
    print(grayMax) 
    gray = grayMax - gray
    gray = log(42, gray)
    # gray = gamma(gray, 0.00000005, 4.0)
    cv2.imshow('gray', gray)
    cv2.waitKey(0)

    ###值方圖均衡化
    clahe = cv2.createCLAHE(clipLimit=1)  #1
    clahe_img = clahe.apply(gray)
    clahe_img = cv2.medianBlur(clahe_img, parmDict['blurvalue']) 
    
    cv2.imshow('claheImg', clahe_img)
    cv2.waitKey(0)    

    ###提取輪廓
    thresh = cv2.adaptiveThreshold(clahe_img, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, parmDict['binaryroil'], parmDict['binaryvaluel'])
    thresh2 = cv2.adaptiveThreshold(clahe_img, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, parmDict['binaryroih'], parmDict['binaryvalueh'])
    cv2.imshow('thresh', thresh2)
    cv2.waitKey(0) 
    thresh[thresh2==0]=0

    ###於板內邊緣塗白邊(確保最大外接矩形正確)
    cv2.polylines(thresh, [points_pair], isClosed= True, color=(255,255,255), thickness=11)

    ###於板外面積塗白(確保黑色區域皆為Defect)
    cv2.fillPoly(thresh, [points], color=255)

    ###尋找所有矩形
    countours, _ = cv2.findContours(thresh, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    max_contour = max(countours, key=cv2.contourArea)

    isNG = False
    for c in countours:
        ###假如為最大外接矩形不做任何動作
        if np.array_equal(c, max_contour):
            pass
        else:
            isNG = True
            cv2.drawContours(result, [c], 0, (0, 0, 255), 1)

    ###檢測結果並輸出
    if isNG:
        status = "NG"
        # cv2.imwrite(os.path.join(savePath, status, 'Orig', '{}_cam{}.jpg'.format(timeNow.strftime("%H_%M_%S"), device)), imageOrgi)
        cv2.imwrite(os.path.join(savePath, status, 'Orig', '{}.jpg'.format(os.path.splitext(fileName)[0])), imageOrgi)
    else:
        status = "OK"
    # cv2.imwrite(os.path.join(savePath, status, '{}_cam{}.jpg'.format(timeNow.strftime("%H_%M_%S"), device)), result)
    cv2.imwrite(os.path.join(savePath, status, '{}.jpg'.format(os.path.splitext(fileName)[0])), result)

    return result, status

if __name__ == "__main__":
    folderPath = './data/test'
    severParmDict  = ServerPramCfg().cfg_load()

    # 遍历文件夹中的所有文件
    for fileName in os.listdir(folderPath):
        # 拼接文件路径
        name, extension = os.path.splitext(fileName)
        # try:
        timeNow = datetime.now()
        flaw_detect(folderPath, fileName, timeNow, severParmDict)
        # except:
            # print(name)
