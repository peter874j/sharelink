from django.conf.urls import url
from django.urls import path, include
from rest_framework import permissions
from drf_yasg.views import get_schema_view
from drf_yasg import openapi

from .views import (
    HeatmapMainlistView,
    AllCountOneWeekView,
    AllCountTwoWeekView,
    AllCountFilterView,
    AreaVisitorMainlistView,
    HotAreaVisitorView,
    AreaVisitorAllCountLastWeekView,
    AreaVisitorAllCountView,
    AreaVisitorFilterCountView,
    AvgtimeVisitLastWeekView,
    AvgtimeVisitView,
    AvgtimeVisitFilterCountView,
    AreaMainlistView,
    AreaMainlist_Id,
    VisitorMainlistView,
    VisitorMainlist_Id,
    VisitorFilterView,
    AdministerMainlistView,
    AdministerMainlist_Id,
    AvgtimeMainlistView,
    AvgtimeMainlist_Noid,
    CheckPermissionView,
    GenerateCount
)

schema_view = get_schema_view(
    openapi.Info(
        title="ATC Showroom API",
        default_version='1.0.0',
        description="ATC Showroom API清單",
        terms_of_service="http://swagger.io/terms/",
        contact=openapi.Contact(
            name="API Support", email="Jenny.CY.Chiu@auo.com"),
        license=openapi.License(name="BSD License")
    ),
    public=True,
    permission_classes=(permissions.AllowAny,),
)

urlpatterns = [
    url(r'^swagger(?P<format>\.json|\.yaml)$', schema_view.without_ui(cache_timeout=0), name='schema-json'),
    url(r'^swagger/$', schema_view.with_ui('swagger', cache_timeout=0), name='schema-swagger-ui'),
    url(r'^redoc/$', schema_view.with_ui('redoc', cache_timeout=0), name='schema-redoc'),
    url(r'^GetHeatmap$', HeatmapMainlistView.as_view()),
    url(r'^GetAllCountOneWeek$', AllCountOneWeekView.as_view()),
    url(r'^GetAllCountTwoWeek$', AllCountTwoWeekView.as_view()),
    url(r'^GetAllCountFilter$', AllCountFilterView.as_view()),
    url(r'^GetAreaVisitor$', AreaVisitorMainlistView.as_view()),
    url(r'^GetHotAreaVisitor$', HotAreaVisitorView.as_view()),
    url(r'^GetAreaVisitorAllCountLastWeek$', AreaVisitorAllCountLastWeekView.as_view()),
    url(r'^GetAreaVisitorAllCount$', AreaVisitorAllCountView.as_view()),
    url(r'^GetAreaVisitorFilterCount$', AreaVisitorFilterCountView.as_view()),
    url(r'^GetAvgtimeVisitLastWeek$', AvgtimeVisitLastWeekView.as_view()),
    url(r'^GetAvgtimeVisit$', AvgtimeVisitView.as_view()),
    url(r'^GetAvgtimeVisitFilterCount$', AvgtimeVisitFilterCountView.as_view()),
    url(r'^GetAllArea$', AreaMainlistView.as_view()),
    url(r'^GetAreaById/(?P<id>\w+)$', AreaMainlist_Id.as_view()),
    url(r'^GetAllVisitor$', VisitorMainlistView.as_view()),
    url(r'^GetVisitorById/(?P<id>\w+)$', VisitorMainlist_Id.as_view()),
    url(r'^GetVisitorFilter$', VisitorFilterView.as_view()),
    url(r'^GetAllAdminister$', AdministerMainlistView.as_view()),
    url(r'^GetAdministerById/(?P<id>\w+)$', AdministerMainlist_Id.as_view()),
    url(r'^GetAllAvgtime$', AvgtimeMainlistView.as_view()),
    url(r'^GetAvgtimeByNoid/(?P<noid>\w+)$', AvgtimeMainlist_Noid.as_view()),
    url(r'^CheckPermission/(?P<username>\w+)$', CheckPermissionView.as_view()),
    url(r'^GenerateCount$', GenerateCount.as_view()),
]