# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'polov4.ui'
##
## Created by: Qt User Interface Compiler version 5.15.8
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *  # type: ignore
from PySide2.QtGui import *  # type: ignore
from PySide2.QtWidgets import *  # type: ignore


class Ui_Form(object):
    def setupUi(self, Form):
        if not Form.objectName():
            Form.setObjectName(u"Form")
        Form.resize(1715, 978)
        self.normalText6 = QLabel(Form)
        self.normalText6.setObjectName(u"normalText6")
        self.normalText6.setGeometry(QRect(1000, 153, 71, 31))
        font = QFont()
        font.setFamily(u"\u6a19\u6977\u9ad4")
        font.setPointSize(20)
        self.normalText6.setFont(font)
        self.realtimeButton = QPushButton(Form)
        self.realtimeButton.setObjectName(u"realtimeButton")
        self.realtimeButton.setGeometry(QRect(394, 154, 75, 23))
        self.Exit = QPushButton(Form)
        self.Exit.setObjectName(u"Exit")
        self.Exit.setGeometry(QRect(680, 70, 75, 23))
        self.tableWidget = QTableWidget(Form)
        self.tableWidget.setObjectName(u"tableWidget")
        self.tableWidget.setGeometry(QRect(760, 540, 641, 391))
        self.test_button = QPushButton(Form)
        self.test_button.setObjectName(u"test_button")
        self.test_button.setGeometry(QRect(390, 70, 75, 23))
        self.equipmentLabel = QLabel(Form)
        self.equipmentLabel.setObjectName(u"equipmentLabel")
        self.equipmentLabel.setGeometry(QRect(280, 70, 91, 31))
        self.yellowButton = QPushButton(Form)
        self.yellowButton.setObjectName(u"yellowButton")
        self.yellowButton.setGeometry(QRect(540, 30, 75, 23))
        self.yellowButton.setMaximumSize(QSize(75, 16777215))
        self.normalText5 = QLabel(Form)
        self.normalText5.setObjectName(u"normalText5")
        self.normalText5.setGeometry(QRect(1200, 146, 91, 41))
        self.normalText5.setFont(font)
        self.thicknessButton = QPushButton(Form)
        self.thicknessButton.setObjectName(u"thicknessButton")
        self.thicknessButton.setGeometry(QRect(61, 154, 75, 23))
        self.statusLabel = QLabel(Form)
        self.statusLabel.setObjectName(u"statusLabel")
        self.statusLabel.setGeometry(QRect(770, 240, 621, 281))
        font1 = QFont()
        font1.setFamily(u"Arial")
        font1.setPointSize(72)
        self.statusLabel.setFont(font1)
        self.videoLabel = QLabel(Form)
        self.videoLabel.setObjectName(u"videoLabel")
        self.videoLabel.setGeometry(QRect(48, 240, 671, 701))
        self.greenButton = QPushButton(Form)
        self.greenButton.setObjectName(u"greenButton")
        self.greenButton.setGeometry(QRect(700, 30, 75, 23))
        self.greenButton.setMaximumSize(QSize(75, 16777215))
        self.csv_button = QPushButton(Form)
        self.csv_button.setObjectName(u"csv_button")
        self.csv_button.setGeometry(QRect(540, 70, 75, 23))
        self.diameterButton = QPushButton(Form)
        self.diameterButton.setObjectName(u"diameterButton")
        self.diameterButton.setGeometry(QRect(227, 154, 75, 23))
        self.colorTypeComboBox = QComboBox(Form)
        self.colorTypeComboBox.addItem("")
        self.colorTypeComboBox.addItem("")
        self.colorTypeComboBox.addItem("")
        self.colorTypeComboBox.addItem("")
        self.colorTypeComboBox.setObjectName(u"colorTypeComboBox")
        self.colorTypeComboBox.setGeometry(QRect(870, 146, 111, 41))
        self.colorTypeComboBox.setStyleSheet(u"/* style for the QcomboBox */\n"
"#comboBox {\n"
"	qproperty-backgroundColor:#0066B0;\n"
"	border :1px solid #ced4da;\n"
"	border-radius: 4px;\n"
"	padding-left:10 px;\n"
"\n"
"}\n"
"#comboBox::drop-down{\n"
"	border:0px;\n"
"}\n"
"#comboBox::down-arrow{\n"
"	image:url(:/icon/arrow-204-32.ico);\n"
"	width: 12 px;\n"
"	height :12px ;\n"
"	margin-right: 15px;\n"
"}\n"
"#comboBox:on{\n"
"	border 4px solid #c2dbfe;\n"
"}\n"
"\n"
"#comboBox QListView{\n"
"	font-size 12px;\n"
"border: solid rgba(0,0,0,10%);\n"
"padding: 5px;\n"
"background-color: #fff;\n"
"outline: 0px;\n"
"}")
        self.pipelineDiameterComboBox = QComboBox(Form)
        self.pipelineDiameterComboBox.addItem("")
        self.pipelineDiameterComboBox.addItem("")
        self.pipelineDiameterComboBox.addItem("")
        self.pipelineDiameterComboBox.addItem("")
        self.pipelineDiameterComboBox.addItem("")
        self.pipelineDiameterComboBox.addItem("")
        self.pipelineDiameterComboBox.addItem("")
        self.pipelineDiameterComboBox.setObjectName(u"pipelineDiameterComboBox")
        self.pipelineDiameterComboBox.setGeometry(QRect(1280, 146, 111, 41))
        self.pipelineTypeComboBox = QComboBox(Form)
        self.pipelineTypeComboBox.addItem("")
        self.pipelineTypeComboBox.addItem("")
        self.pipelineTypeComboBox.addItem("")
        self.pipelineTypeComboBox.addItem("")
        self.pipelineTypeComboBox.addItem("")
        self.pipelineTypeComboBox.addItem("")
        self.pipelineTypeComboBox.addItem("")
        self.pipelineTypeComboBox.addItem("")
        self.pipelineTypeComboBox.setObjectName(u"pipelineTypeComboBox")
        self.pipelineTypeComboBox.setGeometry(QRect(1080, 146, 111, 41))
        self.redButton = QPushButton(Form)
        self.redButton.setObjectName(u"redButton")
        self.redButton.setGeometry(QRect(390, 30, 75, 23))
        self.redButton.setMaximumSize(QSize(75, 16777215))
        self.textEquipment = QLabel(Form)
        self.textEquipment.setObjectName(u"textEquipment")
        self.textEquipment.setGeometry(QRect(40, 70, 241, 31))
        font2 = QFont()
        font2.setFamily(u"Times New Roman")
        font2.setPointSize(20)
        self.textEquipment.setFont(font2)
        self.normalText4 = QLabel(Form)
        self.normalText4.setObjectName(u"normalText4")
        self.normalText4.setGeometry(QRect(790, 150, 81, 41))
        self.normalText4.setFont(font)
        self.callibrartionButton = QPushButton(Form)
        self.callibrartionButton.setObjectName(u"callibrartionButton")
        self.callibrartionButton.setGeometry(QRect(560, 154, 75, 23))
        self.showImageLabel = QLabel(Form)
        self.showImageLabel.setObjectName(u"showImageLabel")
        self.showImageLabel.setGeometry(QRect(50, 220, 659, 41))
        self.timeLabel = QLabel(Form)
        self.timeLabel.setObjectName(u"timeLabel")
        self.timeLabel.setGeometry(QRect(790, 50, 611, 61))

        self.retranslateUi(Form)

        QMetaObject.connectSlotsByName(Form)
    # setupUi

    def retranslateUi(self, Form):
        Form.setWindowTitle(QCoreApplication.translate("Form", u"Form", None))
        self.normalText6.setText(QCoreApplication.translate("Form", u"\u578b\u865f\uff1a", None))
        self.realtimeButton.setText(QCoreApplication.translate("Form", u"\u5373\u6642\u91cf\u6e2c", None))
        self.Exit.setText(QCoreApplication.translate("Form", u"Exit", None))
        self.test_button.setText(QCoreApplication.translate("Form", u"input", None))
        self.equipmentLabel.setText(QCoreApplication.translate("Form", u"TextLabel", None))
        self.yellowButton.setText(QCoreApplication.translate("Form", u"yellow", None))
        self.normalText5.setText(QCoreApplication.translate("Form", u"\u5c3a\u5bf8\uff1a", None))
        self.thicknessButton.setText(QCoreApplication.translate("Form", u"\u539a\u5ea6\u91cf\u6e2c", None))
        self.statusLabel.setText(QCoreApplication.translate("Form", u"Status", None))
        self.videoLabel.setText(QCoreApplication.translate("Form", u"TextLabel", None))
        self.greenButton.setText(QCoreApplication.translate("Form", u"green", None))
        self.csv_button.setText(QCoreApplication.translate("Form", u"output", None))
        self.diameterButton.setText(QCoreApplication.translate("Form", u"\u5916\u5f91\u91cf\u6e2c", None))
        self.colorTypeComboBox.setItemText(0, QCoreApplication.translate("Form", u"\u7070", None))
        self.colorTypeComboBox.setItemText(1, QCoreApplication.translate("Form", u"\u6a58", None))
        self.colorTypeComboBox.setItemText(2, QCoreApplication.translate("Form", u"\u85cd", None))
        self.colorTypeComboBox.setItemText(3, QCoreApplication.translate("Form", u"\u5176\u4ed6", None))

        self.pipelineDiameterComboBox.setItemText(0, QCoreApplication.translate("Form", u"65", None))
        self.pipelineDiameterComboBox.setItemText(1, QCoreApplication.translate("Form", u"80", None))
        self.pipelineDiameterComboBox.setItemText(2, QCoreApplication.translate("Form", u"90", None))
        self.pipelineDiameterComboBox.setItemText(3, QCoreApplication.translate("Form", u"100", None))
        self.pipelineDiameterComboBox.setItemText(4, QCoreApplication.translate("Form", u"125", None))
        self.pipelineDiameterComboBox.setItemText(5, QCoreApplication.translate("Form", u"150", None))
        self.pipelineDiameterComboBox.setItemText(6, QCoreApplication.translate("Form", u"200", None))

        self.pipelineTypeComboBox.setItemText(0, QCoreApplication.translate("Form", u"A", None))
        self.pipelineTypeComboBox.setItemText(1, QCoreApplication.translate("Form", u"B", None))
        self.pipelineTypeComboBox.setItemText(2, QCoreApplication.translate("Form", u"W", None))
        self.pipelineTypeComboBox.setItemText(3, QCoreApplication.translate("Form", u"E", None))
        self.pipelineTypeComboBox.setItemText(4, QCoreApplication.translate("Form", u"ES1", None))
        self.pipelineTypeComboBox.setItemText(5, QCoreApplication.translate("Form", u"R", None))
        self.pipelineTypeComboBox.setItemText(6, QCoreApplication.translate("Form", u"HIB", None))
        self.pipelineTypeComboBox.setItemText(7, QCoreApplication.translate("Form", u"HIW", None))

        self.redButton.setText(QCoreApplication.translate("Form", u"red", None))
        self.textEquipment.setText(QCoreApplication.translate("Form", u"Equipment Number:", None))
        self.normalText4.setText(QCoreApplication.translate("Form", u"\u984f\u8272\uff1a", None))
        self.callibrartionButton.setText(QCoreApplication.translate("Form", u"\u6821\u6b63\u6a21\u5f0f", None))
        self.showImageLabel.setText("")
        self.timeLabel.setText(QCoreApplication.translate("Form", u"TextLabel", None))
    # retranslateUi

