from PySide2.QtWidgets import QApplication, QWidget, QVBoxLayout, QComboBox

class MainWindow(QWidget):
    def __init__(self):
        super().__init__()

        self.model_size_map = {
            "A": [65, 80, 90, 100, 125, 150, 200],
            "B": [60, 100, 125, 150, 200],
            "W": [65, 80, 100, 125, 150, 200],
            "E": [65, 80, 100, 125, 150, 200],
            "ES1": [80, 100, 125, 150],
            "HIW": [80, 100, 125, 150, 200],
            "R": [125, 150, 200]
        }

        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout()

        self.model_combobox = QComboBox()
        self.size_combobox = QComboBox()

        self.model_combobox.addItems(self.model_size_map.keys())
        self.model_combobox.currentIndexChanged[str].connect(self.update_size_combobox)

        layout.addWidget(self.model_combobox)
        layout.addWidget(self.size_combobox)

        self.setLayout(layout)
        self.update_size_combobox(self.model_combobox.currentText())

    def update_size_combobox(self, model):
        self.size_combobox.clear()
        sizes = self.model_size_map.get(model, [])
        for size in sizes:
            self.size_combobox.addItem(str(size))

if __name__ == "__main__":
    app = QApplication([])
    window = MainWindow()
    window.show()
    app.exec_()