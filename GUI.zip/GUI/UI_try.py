from PySide2.QtWidgets import QApplication, QWidget, QLabel, QVBoxLayout,QHBoxLayout

app = QApplication([])

window = QWidget()
main_layout = QVBoxLayout()

label1 = QLabel("Label 1")
main_layout.addWidget(label1)

horizontal_layout = QHBoxLayout()

label2 = QLabel("Label 2")
horizontal_layout.addWidget(label2)

label3 = QLabel("Label 3")
horizontal_layout.addWidget(label3)

main_layout.addLayout(horizontal_layout)

window.setLayout(main_layout)
window.show()

app.exec_()