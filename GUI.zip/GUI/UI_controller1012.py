import sys

from PySide2.QtCore import Qt

from PySide2.QtWidgets import QApplication, QMainWindow
from UI_1012 import Ui_MainWindow
from PySide2.QtWidgets import *
from PySide2.QtCore import *
from PySide2.QtGui import QImage,QPixmap
from PySide2 import QtCore
from PySide2.QtCore import QLocale
import cv2
from PySide2.QtGui import QColor
import datetime
from HyperlinkItemDelegate import HyperlinkItemDelegate
import pandas as pd
from openpyxl import Workbook
from openpyxl.utils.dataframe import dataframe_to_rows
from openpyxl.styles import Font
import random
import os 
from configparser import ConfigParser
from PySide2.QtGui import QFont
import logging
from Logger import Logger

import qtawesome as qta

logger = Logger()
logger.create_file_handler(
    logFolderPath="./data/logs",
    logfileName="system_log.log",
    maxMB=10,
    backupCount=1,
    level=logging.INFO,
)
logger.create_stream_handler()

data= {
    'A':[65,80,90,100,125,150,200],
    "B":[60,100,125,150,200],
    "W":[65,80,100,125,150,200],
    "E":[65,80,100,125,150,200],
    "ES1":[80,100,125,150],
    "HIW":[80,100,125,150,200],
    "R":[125,150,200],
}


class MainWindow(QMainWindow):
    def __init__(self):
        super(MainWindow, self).__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.setup_control()
        self.installEventFilter(self)
        self.ui.tableWidget.setItemDelegate(HyperlinkItemDelegate(self))
        with open("qbutton.qss",'r') as file :
            buttonContent = file.read()
        self.ui.diameterButton.setStyleSheet(buttonContent)
        self.ui.realtimeButton.setStyleSheet(buttonContent)
        self.ui.callibrartionButton.setStyleSheet(buttonContent)
        self.ui.thicknessButton.setStyleSheet(buttonContent)
        
        
        with open("combobox.qss",'r') as file:
            comboboxContent = file.read()
            self.ui.colorTypeComboBox.setStyleSheet(comboboxContent)
            self.ui.pipelineDiameterComboBox.setStyleSheet(comboboxContent)
            self.ui.pipelineTypeComboBox.setStyleSheet(comboboxContent)
        
        with open('timelabel.qss','r') as file :
            timestyle = file.read()
            # self.ui.timeLabel.setStyleSheet(timestyle)
            self.ui.videoLabel.setStyleSheet(timestyle)
        self.firstCam = True

        
        #設定設備字
        self.cfg = ConfigParser()
        self.cfg.read("setup.cfg",encoding='utf-8')
        self.equipmentNumber = self.cfg["setup"]["equipmentnumber"]
        self.searchFile = self.cfg["setup"]["searchfile"]
        self.ui.equipmentLabel.setText(self.equipmentNumber)
        logger.info(f"使用{self.equipmentNumber}號機台")
        self.font = QFont("Times New Roman",20)
        self.ui.equipmentLabel.setFont(self.font)
        self.ui.equipmentLabel.setAlignment(Qt.AlignLeft)
  
        self.outputfileName = "U:/MarcroPOLO/output.xlsx"
        self.previous_log_time = QDateTime.currentDateTime()


    def setup_control(self):
        self.ui.Exit.clicked.connect(self.ExitButton)
        self.ui.videoLabel.setScaledContents(True) #自適應畫面大小
        self.timer = QTimer()
        self.timer.start(1)
        self.timer.timeout.connect(self.showtime)
        self.videoPath = "tube_video.mp4"
        self.imagePath = "label.png"
        self.imagePath2= "gray_thickness.bmp"
        self.ui.diameterButton.clicked.connect(self.diameterImage)
        self.ui.thicknessButton.clicked.connect(self.thicknessImage)
        self.ui.realtimeButton.clicked.connect(self.realtimeMode)
        self.ui.tableWidget.setColumnCount(6)
        self.headers = ["時間", "生產規格", "厚度值(mm)", "厚度判定", "外徑值", "外徑判定"]
        self.ui.tableWidget.setHorizontalHeaderLabels(self.headers)
        self.ui.callibrartionButton.clicked.connect(self.callibrationMode)
    
        #初始播放狀態
        self.timerVideoActive = True
        self.setupCamera()
        self.capture = cv2.VideoCapture(self.videoPath)
        self.timerVideo = QTimer()
        self.timerVideo.timeout.connect(self.displayVideoStream)
        self.timerVideo.start(30)        

        self.ui.statusLabel.setStyleSheet
        self.stylesheets = ["Red.qss", "Yellow.qss","Green.qss","Init.qss" ]
        self.ui.redButton.clicked.connect(self.redClick)
        self.ui.yellowButton.clicked.connect(self.yellowClick)
        self.ui.greenButton.clicked.connect(self.greenClick)
        self.statustimer = QTimer()
        self.ui.test_button.clicked.connect(self.addRow)
        self.ui.csv_button.clicked.connect(self.saveTocsv)


        #初始化顯示正常
        ###TODO 增加條件才能初始正常
        with open(self.stylesheets[2], "r") as file:
            stylesheet = file.read()
            self.ui.statusLabel.setText("系統正常")
            self.ui.statusLabel.setStyleSheet(stylesheet)
            self.ui.statusLabel.update()
        
        # 初始化管型 QComboBox
        self.ui.pipelineTypeComboBox.clear()
        for pipe_type in data.keys():
            self.ui.pipelineTypeComboBox.addItem(pipe_type)

        # 当管型 QComboBox 更改时更新尺寸 QComboBox 的内容
        self.ui.pipelineTypeComboBox.currentIndexChanged.connect(self.update_sizes)

        # 初始化尺寸 QComboBox
        self.update_sizes(0)        
        self.ui.pipelineTypeComboBox.currentIndexChanged.connect(self.showMessageWindow1)
        self.ui.colorTypeComboBox.currentIndexChanged.connect(self.showMessageWindow2)
        self.ui.pipelineDiameterComboBox.currentIndexChanged.connect(self.showMessageWindow3)
        self.comboboxPreviousIndex1=0
        self.comboboxPreviousIndex2=0
        self.comboboxPreviousIndex3=0
        self.colotTpye=None
        self.pipelineType=None
        self.pipelineDiameter=None        

    def diameterImage(self):
        latest_image_path = None


        diameterImage = "diameterPic"
        files = [os.path.join(diameterImage, f) for f in os.listdir(diameterImage) if os.path.isfile(os.path.join(diameterImage, f))]
        files.sort(key=lambda x: os.path.getmtime(x), reverse=True)
        
        if files:
            latest_image_path = files[0]
            lastName = latest_image_path.split("\\")[-1]
            text = "目前顯示的圖片為"+str(lastName)
            self.ui.showImageLabel.setText(text)
            self.ui.showImageLabel.setAlignment(Qt.AlignHCenter)
        else:
            msg = QMessageBox()
            msg.setIcon(QMessageBox.Information)
            msg.setWindowTitle("系統提示")
            msg.setText("沒有找到圖片")
            msg.exec_()
        if latest_image_path:
            
            if self.timerVideoActive:
                self.timerVideoActive = False
                self.timerVideo.stop()
                QApplication.processEvents()
        
            self.ui.videoLabel.clear()
            self.qpixmap = QPixmap()
            self.qpixmap.load(latest_image_path)
            self.ui.videoLabel.setPixmap(self.qpixmap)

    def thicknessImage(self):
        latest_image_path = None
        if self.timerVideoActive:
            self.timerVideoActive = False
            self.timerVideo.stop()
            QApplication.processEvents()

        thicknessImage = "thicknessPic"
        files = [os.path.join(thicknessImage, f) for f in os.listdir(thicknessImage) if os.path.isfile(os.path.join(thicknessImage, f))]
        files.sort(key=lambda x: os.path.getmtime(x), reverse=True)

        if files:
            latest_image_path = files[0]
            lastName = latest_image_path.split("\\")[-1]
            text = "目前顯示的圖片為"+str(lastName)
            self.ui.showImageLabel.setText(text)
            self.ui.showImageLabel.setAlignment(Qt.AlignHCenter)
        else:
            msg = QMessageBox()
            msg.setIcon(QMessageBox.Information)
            msg.setWindowTitle("系統提示")
            msg.setText("沒有找到圖片")
            msg.exec_()
        if latest_image_path:
            if self.timerVideoActive:
                self.timerVideoActive = False
                self.timerVideo.stop()
                QApplication.processEvents()
            self.ui.videoLabel.clear()
            self.qpixmap = QPixmap()
            self.qpixmap.load(latest_image_path)
            self.ui.videoLabel.setPixmap(self.qpixmap)
            
    def realtimeMode (self):
        self.setupCamera()
        if not self.timerVideoActive: 
            self.timerVideo.start(30)
            self.timerVideoActive = True
 
    def update_sizes(self, index):
        self.ui.pipelineDiameterComboBox.blockSignals(True)  # 阻止訊號
        self.ui.pipelineDiameterComboBox.clear()
        for size in data[self.ui.pipelineTypeComboBox.currentText()]:
            self.ui.pipelineDiameterComboBox.addItem(str(size))
        self.ui.pipelineDiameterComboBox.blockSignals(False)  # 恢復訊號
        
    def setupCamera(self):
        self.capture = cv2.VideoCapture(self.videoPath)
        self.timerVideo = QTimer()
        self.timerVideo.timeout.connect(self.displayVideoStream)
        self.timerVideo.start(30)
        
    def displayVideoStream(self):
        ret, self.frame = self.capture.read()
        
        if self.firstCam & ret & os.path.isfile(self.searchFile) :
         
            logger.info("讀入攝影機")
            self.greenClick
            self.firstCam = False
        if not ret:
            with open(self.stylesheets[1], "r") as file:
                stylesheet = file.read()
                self.ui.statusLabel.setText("系統異常")
                self.ui.statusLabel.setStyleSheet(stylesheet)
                self.ui.statusLabel.update()
            logger.error("攝影機無畫面")
            self.timerVideo.stop()
        self.frame = cv2.cvtColor(self.frame, cv2.COLOR_BGR2RGB)
        self.image = QImage(
            self.frame,
            self.frame.shape[1],
            self.frame.shape[0],
            self.frame.strides[0],
            QImage.Format_RGB888,
        )
        self.ui.videoLabel.setPixmap(QPixmap.fromImage(self.image))
    #顯示時間
    def showtime(self):
        time = QDateTime.currentDateTime()
        timedisplay = time.toString("yyyy-MM-dd hh:mm:ss dddd")
        
        english_locale = QLocale(QLocale.English)
        timedisplay = english_locale.toString(time, "yyyy-MM-dd hh:mm:ss ddd.")
        self.ui.timeLabel.setFont(self.font)
        self.ui.timeLabel.setAlignment(Qt.AlignCenter)
        self.ui.timeLabel.setText(timedisplay)
    
    def captureLabelScreen(self):
        screenshot = QPixmap.grabWidget(self.ui.videoLabel)
        screenshot.save("label.png","JPG")
###測試按鈕
    def redClick(self):
        with open(self.stylesheets[0], "r") as file:
            stylesheet = file.read()
            self.ui.statusLabel.setText("管材NG")
            self.ui.statusLabel.setStyleSheet(stylesheet)
            self.ui.statusLabel.update()

    def yellowClick(self):
        with open(self.stylesheets[1], "r") as file:
            stylesheet = file.read()
            self.ui.statusLabel.setText("系統異常")
            self.ui.statusLabel.setStyleSheet(stylesheet)
            self.ui.statusLabel.update()
            
    def greenClick(self):
        with open(self.stylesheets[2], "r") as file:
            stylesheet = file.read()
            self.ui.statusLabel.setText("系統正常")
            self.ui.statusLabel.setStyleSheet(stylesheet)
            self.ui.statusLabel.update()
####################
    def showMessageWindow1(self, index):
        if index > -1:  
            QTimer.singleShot(0, lambda: self.showMessage(index))

    def showMessage(self, index):
        messageBox = QMessageBox(self)
        messageBox.setWindowTitle("確認視窗")  
        messageBox.setText("目前規格：\n顏色：{}\n管型：{}\n規格：{}".format(self.ui.colorTypeComboBox.currentText(),
                                                                self.ui.pipelineTypeComboBox.currentText(),
                                                                self.ui.pipelineDiameterComboBox.currentText()))

        confirm_button = messageBox.addButton("確認", QMessageBox.AcceptRole)
        cancel_button = messageBox.addButton("取消", QMessageBox.RejectRole)
        messageBox.exec_()
        if messageBox.clickedButton() == cancel_button:
            self.ui.pipelineTypeComboBox.blockSignals(True)
            self.ui.pipelineTypeComboBox.setCurrentIndex(self.comboboxPreviousIndex1)
            self.ui.pipelineTypeComboBox.blockSignals(False)
        else:
            self.comboboxPreviousIndex1 = index
            self.colotTpye=self.ui.colorTypeComboBox.currentText()
            self.pipelineType=self.ui.pipelineTypeComboBox.currentText()
            self.pipelineDiameter=self.ui.pipelineDiameterComboBox.currentText()
            logger.info("目前規格：顏色：{} 管型：{} 規格：{}".format(self.ui.colorTypeComboBox.currentText(),
                                                                    self.ui.pipelineTypeComboBox.currentText(),
                                                                    self.ui.pipelineDiameterComboBox.currentText()))

                
    def showMessageWindow2(self, index):
    
        messageBox = QMessageBox(self)
        messageBox.setWindowTitle("確認視窗")  
        messageBox.setText("目前規格：\n顏色：{}\n管型：{}\n規格：{}".format(self.ui.colorTypeComboBox.currentText(),
                                                                self.ui.pipelineTypeComboBox.currentText(),
                                                                self.ui.pipelineDiameterComboBox.currentText()))
        confirm_button = messageBox.addButton("確認", QMessageBox.AcceptRole)
        cancel_button = messageBox.addButton("取消", QMessageBox.RejectRole)
        messageBox.exec_()
        if messageBox.clickedButton() == cancel_button:
            self.ui.colorTypeComboBox.currentIndexChanged.disconnect(self.showMessageWindow2) 
            self.ui.colorTypeComboBox.setCurrentIndex(self.comboboxPreviousIndex2)
            self.ui.colorTypeComboBox.currentIndexChanged.connect(self.showMessageWindow2)
        else:
            self.comboboxPreviousIndex2 = index
            self.colotTpye=self.ui.colorTypeComboBox.currentText()
            self.pipelineType=self.ui.pipelineTypeComboBox.currentText()
            self.pipelineDiameter=self.ui.pipelineDiameterComboBox.currentText()              
            logger.info("目前規格：顏色：{} 管型：{} 規格：{}".format(self.ui.colorTypeComboBox.currentText(),
                                                                self.ui.pipelineTypeComboBox.currentText(),
                                                                self.ui.pipelineDiameterComboBox.currentText()))

      
    def showMessageWindow3(self, index):
        messageBox = QMessageBox(self)
        messageBox.setWindowTitle("確認視窗")  # 將標題設置為 "確認視窗"
        messageBox.setText("目前規格：\n顏色：{}\n管型：{}\n規格：{}".format(self.ui.colorTypeComboBox.currentText(),
                                                                self.ui.pipelineTypeComboBox.currentText(),
                                                                self.ui.pipelineDiameterComboBox.currentText()))

        confirm_button = messageBox.addButton("確認", QMessageBox.AcceptRole)
        cancel_button = messageBox.addButton("取消", QMessageBox.RejectRole)
        messageBox.exec_()
        if messageBox.clickedButton() == cancel_button:
            self.ui.pipelineDiameterComboBox.currentIndexChanged.disconnect(self.showMessageWindow3)  # 断开连接
            self.ui.pipelineDiameterComboBox.setCurrentIndex(self.comboboxPreviousIndex3)
            self.ui.pipelineDiameterComboBox.currentIndexChanged.connect(self.showMessageWindow3)  # 重新连接
        else:
            self.comboboxPreviousIndex3 = index
            self.colotTpye=self.ui.colorTypeComboBox.currentText()
            self.pipelineType=self.ui.pipelineTypeComboBox.currentText()
            self.pipelineDiameter=self.ui.pipelineDiameterComboBox.currentText()
            logger.info("目前規格：顏色：{} 管型：{} 規格：{}".format(self.ui.colorTypeComboBox.currentText(),
                                                                self.ui.pipelineTypeComboBox.currentText(),
                                                                self.ui.pipelineDiameterComboBox.currentText()))
                    # print(self.pipelineType,self.colotTpye,self.pipelineDiameter)        

    def eventFilter(self, obj, event):
        if event.type() == QEvent.KeyPress and event.key() == Qt.Key_Escape:
            if self.windowState() & Qt.WindowFullScreen:
                self.setWindowState(Qt.WindowNoState)
                self.ui.videoLabel.setParent(self.ui.centralwidget)
                self.ui.videoLabel.setGeometry(QRect(18, 220, 671, 701))  
                self.ui.videoLabel.show()
            return True
        elif event.type() == QEvent.KeyPress and event.key() == Qt.Key_Space:
            if self.windowState() & Qt.WindowFullScreen:
                self.setWindowState(Qt.WindowNoState)
                self.ui.videoLabel.setParent(self.ui.centralwidget)
                self.ui.videoLabel.setGeometry(QRect(18, 220, 671, 701))  
                self.ui.videoLabel.show()
            return True
        return super().eventFilter(obj, event)


    def toggleFullScreen(self):
        if self.windowState() & Qt.WindowFullScreen:
            self.setWindowState(Qt.WindowNoState)
            self.ui.videoLabel.setParent(self.ui.centralwidget)
            self.ui.videoLabel.setGeometry(QRect(120, 210, 581, 561))  
            self.ui.videoLabel.show()
        else:
            self.setWindowState(Qt.WindowFullScreen)
            self.ui.videoLabel.setParent(self)
            self.ui.videoLabel.setGeometry(self.geometry())
            self.ui.videoLabel.show()
            messageBoxScreen = QMessageBox(self)
            messageBoxScreen.setWindowTitle("系統提示")
            messageBoxScreen.setText("按下 ESC 鍵退出全螢幕模式")
            messageBoxScreen.setIcon(QMessageBox.Information)
            messageBoxScreen.setStandardButtons(QMessageBox.Ok)
            messageBoxScreen.exec_()



    def callibrationMode(self):
        if self.windowState() & Qt.WindowFullScreen:
            self.setWindowState(Qt.WindowNoState)
            self.ui.videoLabel.setParent(self.ui.centralwidget)
            self.ui.videoLabel.setGeometry(QRect(120, 210, 581, 561))  
            self.ui.videoLabel.show()
        else:
            self.setWindowState(Qt.WindowFullScreen)
            self.ui.videoLabel.setParent(self)
            self.ui.videoLabel.setGeometry(self.geometry())
            self.ui.videoLabel.show()
            messageBoxScreen = QMessageBox(self)
            messageBoxScreen.setWindowTitle("系統提示")
            messageBoxScreen.setText("按下 ESC 鍵退出全螢幕模式")
            messageBoxScreen.setIcon(QMessageBox.Information)
            messageBoxScreen.setStandardButtons(QMessageBox.Ok)
            messageBoxScreen.exec_()        


    def addRow(self):
        screenshot = self.ui.videoLabel.grab()
        currentTime= QDateTime.currentDateTime().toString("MM_dd_hh_mm_ss")
        fileName= f"{currentTime}.png"
    
        screenshot.save(fileName,"JPG")
        current_row = self.ui.tableWidget.rowCount()
        self.ui.tableWidget.insertRow(current_row)

            
        diameter_folder = "diameterPic"
        thickness_folder = "thicknessPic"
        os.makedirs(diameter_folder, exist_ok=True)
        os.makedirs(thickness_folder, exist_ok=True)

        # 保存截图到两个文件夹中
        screenshot.save(os.path.join(diameter_folder, fileName), "JPG")
        screenshot.save(os.path.join(thickness_folder, fileName), "JPG")
        
        # 時間
        date = QDateTime.currentDateTime().toString("MM/dd hh:mm:ss")
        date_item = QTableWidgetItem(date)
        date_item.setTextAlignment(Qt.AlignCenter)
        self.ui.tableWidget.setItem(current_row, 0, date_item)

        # 生產規格
        self.color = self.ui.colorTypeComboBox.currentText()
        self.model = self.ui.pipelineTypeComboBox.currentText()
        self.size = self.ui.pipelineDiameterComboBox.currentText()
        specification = f"{self.color}-{self.model}-{self.size}"
        specification_item = QTableWidgetItem(specification)
        specification_item.setTextAlignment(Qt.AlignCenter)
        self.ui.tableWidget.setItem(current_row, 1, specification_item)

        # 厚度值(mm)
        thickness_value = round(random.uniform(1, 10), 2)
        thickness_item = QTableWidgetItem(str(thickness_value))
        thickness_item.setTextAlignment(Qt.AlignCenter)
        self.ui.tableWidget.setItem(current_row, 2, thickness_item)

        # 厚度判定
        status_choices = ["OK", "NG"]
        
        status1 = random.choice(status_choices)
        status1_item = QTableWidgetItem(status1)
        status1_item.setTextAlignment(Qt.AlignCenter)

        if status1 == "NG":
            status1_item.setBackground(QColor("red"))
        elif status1 =="OK":
            status1_item.setBackground(QColor("green"))

        self.ui.tableWidget.setItem(current_row, 3, status1_item)

        # 外徑值
        outer_diameter_value = round(random.uniform(1, 10), 2)
        outer_diameter_item = QTableWidgetItem(str(outer_diameter_value))
        outer_diameter_item.setTextAlignment(Qt.AlignCenter)
        self.ui.tableWidget.setItem(current_row, 4, outer_diameter_item)

        # 外徑判定
        status2 = random.choice(status_choices)
        status2_item = QTableWidgetItem(status2)
        status2_item.setTextAlignment(Qt.AlignCenter)

        if status2 == "NG":
            status2_item.setBackground(QColor("red"))
        elif status2 =="OK":
            status2_item.setBackground(QColor("green"))
            
            
        if status1 == "NG" or status2 == "NG":
            with open(self.stylesheets[0], "r") as file:
                stylesheet = file.read()
                self.ui.statusLabel.setText("管材NG")
                self.ui.statusLabel.setStyleSheet(stylesheet)
                self.ui.statusLabel.update()
                logger.info("管材NG!!")
        else:
            with open(self.stylesheets[2], "r") as file:
                stylesheet = file.read()
                self.ui.statusLabel.setText("系統正常")
                self.ui.statusLabel.setStyleSheet(stylesheet)
                self.ui.statusLabel.update()
                logger.info("規格正常")

        self.ui.tableWidget.setItem(current_row, 5, status2_item)  # 更改此處的列索引為6
        self.ui.tableWidget.scrollToBottom()
            
    
    def saveTocsv(self):

        data = []
        for row in range(self.ui.tableWidget.rowCount()):
            row_data = []
            current_year = datetime.datetime.now().year
            # Get the time from tableWidget's first column
            item = self.ui.tableWidget.item(row, 0)
            cell_text = item.text()
            time_text = f'{current_year} {cell_text}'
            row_data.append(time_text)

            for column in range(1, 2):
                item = self.ui.tableWidget.item(row, column)
                cell_text = item.text()
                parts = cell_text.split("-")
                color = parts[0]
                model = parts[1]
                size  = parts[2]
                
                row_data.append(color)
                row_data.append(model)
                row_data.append(size)
                
            #找公差
            df = pd.read_excel(self.searchFile)
            modelSizeStr = f"{model}-{size}"
            matchedRow = df.loc[df["規格"] == modelSizeStr]
            
            if not matchedRow.empty:
                thicknessTolerance = matchedRow["厚度公差"].values[0]
                diameterTolerance = matchedRow["外徑公差"].values[0]

            else:
                thicknessTolerance = "未找到對應公差"
                diameterTolerance = "未找到對應公差"
                
            row_data.append(thicknessTolerance)
            
            
            for column in range(2, 4):
                item = self.ui.tableWidget.item(row, column)
                cell_text = item.text()
                row_data.append(cell_text)
            
            row_data.append(diameterTolerance)
            
            # Start iterating from the first column instead of the second one
            for column in range(4, self.ui.tableWidget.columnCount()):
                item = self.ui.tableWidget.item(row, column)
                cell_text = item.text()
                row_data.append(cell_text)
            data.append(row_data)

        headers = ["時間", "顏色", "型號", "尺寸", "厚度公差","厚度值(mm)", "厚度判定", "外徑公差","外徑值", "外徑判定"]
        df = pd.DataFrame(data, columns=headers)

        wb = Workbook()
        ws = wb.active

        for r in dataframe_to_rows(df, index=False, header=True):
            ws.append(r)
        
        for row in ws.iter_rows():
            for cell in row:
                if 'NG' in str(cell.value):
                    cell.font = Font(color='FF0000')
                elif 'OK' in str(cell.value):
                    cell.font = Font(color='008000')
        try:
            wb.save(self.outputfileName)
        except PermissionError as e:
            logger.error(f"無法保存文件 '{self.outputfileName}'：{e}")

        self.ui.tableWidget.setRowCount(0)

    def ExitButton(self):
        QCoreApplication.instance().quit()




if __name__ == "__main__":
    QtCore.QCoreApplication.setAttribute(QtCore.Qt.AA_EnableHighDpiScaling)
    app = QApplication (sys.argv)
    ui = MainWindow()
    ui.show()
    app.exec_()