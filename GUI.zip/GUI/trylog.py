from Logger import Logger

logger = Logger()
logger.create_file_handler(
    logFolderPath="./data/logs",
    logfileName="system_log.log",
    maxMB=10,
    backupCount=1,
)
logger.create_stream_handler()

logger.debug("這是一條調試信息")
logger.info("這是一條信息級別的日誌")
logger.warning("這是一條警告信息")
logger.error("這是一個錯誤信息")
logger.critical("這是一個嚴重錯誤信息")