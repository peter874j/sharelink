# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'polowidgetV2.ui'
##
## Created by: Qt User Interface Compiler version 5.15.8
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *  # type: ignore
from PySide2.QtGui import *  # type: ignore
from PySide2.QtWidgets import *  # type: ignore


class Ui_Form(object):
    def setupUi(self, Form):
        if not Form.objectName():
            Form.setObjectName(u"Form")
        Form.resize(1376, 966)
        sizePolicy = QSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(Form.sizePolicy().hasHeightForWidth())
        Form.setSizePolicy(sizePolicy)
        Form.setMinimumSize(QSize(700, 450))
        self.horizontalLayoutWidget = QWidget(Form)
        self.horizontalLayoutWidget.setObjectName(u"horizontalLayoutWidget")
        self.horizontalLayoutWidget.setGeometry(QRect(10, 10, 1311, 80))
        self.horizontalLayout = QHBoxLayout(self.horizontalLayoutWidget)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.horizontalLayout.setContentsMargins(0, 0, 0, 0)
        self.textEquipment = QLabel(self.horizontalLayoutWidget)
        self.textEquipment.setObjectName(u"textEquipment")
        font = QFont()
        font.setFamily(u"Times New Roman")
        font.setPointSize(20)
        self.textEquipment.setFont(font)

        self.horizontalLayout.addWidget(self.textEquipment)

        self.equipmentLabel = QLabel(self.horizontalLayoutWidget)
        self.equipmentLabel.setObjectName(u"equipmentLabel")
        sizePolicy1 = QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.equipmentLabel.sizePolicy().hasHeightForWidth())
        self.equipmentLabel.setSizePolicy(sizePolicy1)

        self.horizontalLayout.addWidget(self.equipmentLabel)

        self.horizontalSpacer = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout.addItem(self.horizontalSpacer)

        self.test_button = QPushButton(self.horizontalLayoutWidget)
        self.test_button.setObjectName(u"test_button")

        self.horizontalLayout.addWidget(self.test_button)

        self.csv_button = QPushButton(self.horizontalLayoutWidget)
        self.csv_button.setObjectName(u"csv_button")

        self.horizontalLayout.addWidget(self.csv_button)

        self.Exit = QPushButton(self.horizontalLayoutWidget)
        self.Exit.setObjectName(u"Exit")

        self.horizontalLayout.addWidget(self.Exit)

        self.horizontalSpacer_2 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout.addItem(self.horizontalSpacer_2)

        self.timeLabel = QLabel(self.horizontalLayoutWidget)
        self.timeLabel.setObjectName(u"timeLabel")

        self.horizontalLayout.addWidget(self.timeLabel)

        self.horizontalLayoutWidget_2 = QWidget(Form)
        self.horizontalLayoutWidget_2.setObjectName(u"horizontalLayoutWidget_2")
        self.horizontalLayoutWidget_2.setGeometry(QRect(10, 100, 1311, 80))
        self.horizontalLayout_2 = QHBoxLayout(self.horizontalLayoutWidget_2)
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.horizontalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.callibrartionButton = QPushButton(self.horizontalLayoutWidget_2)
        self.callibrartionButton.setObjectName(u"callibrartionButton")
        sizePolicy2 = QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        sizePolicy2.setHorizontalStretch(0)
        sizePolicy2.setVerticalStretch(0)
        sizePolicy2.setHeightForWidth(self.callibrartionButton.sizePolicy().hasHeightForWidth())
        self.callibrartionButton.setSizePolicy(sizePolicy2)
        self.callibrartionButton.setMinimumSize(QSize(20, 20))

        self.horizontalLayout_2.addWidget(self.callibrartionButton)

        self.realtimeButton = QPushButton(self.horizontalLayoutWidget_2)
        self.realtimeButton.setObjectName(u"realtimeButton")
        sizePolicy2.setHeightForWidth(self.realtimeButton.sizePolicy().hasHeightForWidth())
        self.realtimeButton.setSizePolicy(sizePolicy2)

        self.horizontalLayout_2.addWidget(self.realtimeButton)

        self.diameterButton = QPushButton(self.horizontalLayoutWidget_2)
        self.diameterButton.setObjectName(u"diameterButton")
        sizePolicy2.setHeightForWidth(self.diameterButton.sizePolicy().hasHeightForWidth())
        self.diameterButton.setSizePolicy(sizePolicy2)

        self.horizontalLayout_2.addWidget(self.diameterButton)

        self.thicknessButton = QPushButton(self.horizontalLayoutWidget_2)
        self.thicknessButton.setObjectName(u"thicknessButton")
        sizePolicy2.setHeightForWidth(self.thicknessButton.sizePolicy().hasHeightForWidth())
        self.thicknessButton.setSizePolicy(sizePolicy2)

        self.horizontalLayout_2.addWidget(self.thicknessButton)

        self.horizontalSpacer_5 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_2.addItem(self.horizontalSpacer_5)

        self.normalText4 = QLabel(self.horizontalLayoutWidget_2)
        self.normalText4.setObjectName(u"normalText4")
        font1 = QFont()
        font1.setFamily(u"\u6a19\u6977\u9ad4")
        font1.setPointSize(20)
        self.normalText4.setFont(font1)

        self.horizontalLayout_2.addWidget(self.normalText4)

        self.colorTypeComboBox = QComboBox(self.horizontalLayoutWidget_2)
        self.colorTypeComboBox.addItem("")
        self.colorTypeComboBox.addItem("")
        self.colorTypeComboBox.addItem("")
        self.colorTypeComboBox.addItem("")
        self.colorTypeComboBox.setObjectName(u"colorTypeComboBox")
        sizePolicy2.setHeightForWidth(self.colorTypeComboBox.sizePolicy().hasHeightForWidth())
        self.colorTypeComboBox.setSizePolicy(sizePolicy2)
        self.colorTypeComboBox.setStyleSheet(u"/* style for the QcomboBox */\n"
"#comboBox {\n"
"	qproperty-backgroundColor:#0066B0;\n"
"	border :1px solid #ced4da;\n"
"	border-radius: 4px;\n"
"	padding-left:10 px;\n"
"\n"
"}\n"
"#comboBox::drop-down{\n"
"	border:0px;\n"
"}\n"
"#comboBox::down-arrow{\n"
"	image:url(:/icon/arrow-204-32.ico);\n"
"	width: 12 px;\n"
"	height :12px ;\n"
"	margin-right: 15px;\n"
"}\n"
"#comboBox:on{\n"
"	border 4px solid #c2dbfe;\n"
"}\n"
"\n"
"#comboBox QListView{\n"
"	font-size 12px;\n"
"border: solid rgba(0,0,0,10%);\n"
"padding: 5px;\n"
"background-color: #fff;\n"
"outline: 0px;\n"
"}")

        self.horizontalLayout_2.addWidget(self.colorTypeComboBox)

        self.normalText6 = QLabel(self.horizontalLayoutWidget_2)
        self.normalText6.setObjectName(u"normalText6")
        sizePolicy3 = QSizePolicy(QSizePolicy.Minimum, QSizePolicy.Minimum)
        sizePolicy3.setHorizontalStretch(0)
        sizePolicy3.setVerticalStretch(0)
        sizePolicy3.setHeightForWidth(self.normalText6.sizePolicy().hasHeightForWidth())
        self.normalText6.setSizePolicy(sizePolicy3)
        self.normalText6.setFont(font1)

        self.horizontalLayout_2.addWidget(self.normalText6)

        self.pipelineTypeComboBox = QComboBox(self.horizontalLayoutWidget_2)
        self.pipelineTypeComboBox.addItem("")
        self.pipelineTypeComboBox.addItem("")
        self.pipelineTypeComboBox.addItem("")
        self.pipelineTypeComboBox.addItem("")
        self.pipelineTypeComboBox.addItem("")
        self.pipelineTypeComboBox.addItem("")
        self.pipelineTypeComboBox.addItem("")
        self.pipelineTypeComboBox.addItem("")
        self.pipelineTypeComboBox.setObjectName(u"pipelineTypeComboBox")
        sizePolicy2.setHeightForWidth(self.pipelineTypeComboBox.sizePolicy().hasHeightForWidth())
        self.pipelineTypeComboBox.setSizePolicy(sizePolicy2)

        self.horizontalLayout_2.addWidget(self.pipelineTypeComboBox)

        self.normalText5 = QLabel(self.horizontalLayoutWidget_2)
        self.normalText5.setObjectName(u"normalText5")
        self.normalText5.setFont(font1)

        self.horizontalLayout_2.addWidget(self.normalText5)

        self.pipelineDiameterComboBox = QComboBox(self.horizontalLayoutWidget_2)
        self.pipelineDiameterComboBox.addItem("")
        self.pipelineDiameterComboBox.addItem("")
        self.pipelineDiameterComboBox.addItem("")
        self.pipelineDiameterComboBox.addItem("")
        self.pipelineDiameterComboBox.addItem("")
        self.pipelineDiameterComboBox.addItem("")
        self.pipelineDiameterComboBox.addItem("")
        self.pipelineDiameterComboBox.setObjectName(u"pipelineDiameterComboBox")
        sizePolicy2.setHeightForWidth(self.pipelineDiameterComboBox.sizePolicy().hasHeightForWidth())
        self.pipelineDiameterComboBox.setSizePolicy(sizePolicy2)

        self.horizontalLayout_2.addWidget(self.pipelineDiameterComboBox)

        self.gridLayoutWidget = QWidget(Form)
        self.gridLayoutWidget.setObjectName(u"gridLayoutWidget")
        self.gridLayoutWidget.setGeometry(QRect(10, 190, 1311, 771))
        self.gridLayout = QGridLayout(self.gridLayoutWidget)
        self.gridLayout.setObjectName(u"gridLayout")
        self.gridLayout.setContentsMargins(9, 0, 0, 0)
        self.tableWidget = QTableWidget(self.gridLayoutWidget)
        self.tableWidget.setObjectName(u"tableWidget")
        sizePolicy1.setHeightForWidth(self.tableWidget.sizePolicy().hasHeightForWidth())
        self.tableWidget.setSizePolicy(sizePolicy1)

        self.gridLayout.addWidget(self.tableWidget, 2, 2, 1, 1)

        self.horizontalSpacer_4 = QSpacerItem(40, 20, QSizePolicy.Minimum, QSizePolicy.Minimum)

        self.gridLayout.addItem(self.horizontalSpacer_4, 2, 1, 1, 1)

        self.videoLabel = QLabel(self.gridLayoutWidget)
        self.videoLabel.setObjectName(u"videoLabel")
        sizePolicy1.setHeightForWidth(self.videoLabel.sizePolicy().hasHeightForWidth())
        self.videoLabel.setSizePolicy(sizePolicy1)

        self.gridLayout.addWidget(self.videoLabel, 2, 0, 1, 1)

        self.horizontalSpacer_3 = QSpacerItem(40, 20, QSizePolicy.Maximum, QSizePolicy.Minimum)

        self.gridLayout.addItem(self.horizontalSpacer_3, 0, 1, 1, 1)

        self.showImageLabel = QLabel(self.gridLayoutWidget)
        self.showImageLabel.setObjectName(u"showImageLabel")
        sizePolicy1.setHeightForWidth(self.showImageLabel.sizePolicy().hasHeightForWidth())
        self.showImageLabel.setSizePolicy(sizePolicy1)

        self.gridLayout.addWidget(self.showImageLabel, 0, 0, 1, 1)

        self.statusLabel = QLabel(self.gridLayoutWidget)
        self.statusLabel.setObjectName(u"statusLabel")
        sizePolicy1.setHeightForWidth(self.statusLabel.sizePolicy().hasHeightForWidth())
        self.statusLabel.setSizePolicy(sizePolicy1)
        font2 = QFont()
        font2.setFamily(u"Arial")
        font2.setPointSize(72)
        self.statusLabel.setFont(font2)

        self.gridLayout.addWidget(self.statusLabel, 0, 2, 1, 1)

        self.verticalSpacer = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Maximum)

        self.gridLayout.addItem(self.verticalSpacer, 1, 0, 1, 1)

        self.verticalSpacer_2 = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Maximum)

        self.gridLayout.addItem(self.verticalSpacer_2, 1, 2, 1, 1)


        self.retranslateUi(Form)

        QMetaObject.connectSlotsByName(Form)
    # setupUi

    def retranslateUi(self, Form):
        Form.setWindowTitle(QCoreApplication.translate("Form", u"Form", None))
        self.textEquipment.setText(QCoreApplication.translate("Form", u"Equipment Number:", None))
        self.equipmentLabel.setText(QCoreApplication.translate("Form", u"TextLabel", None))
        self.test_button.setText(QCoreApplication.translate("Form", u"input", None))
        self.csv_button.setText(QCoreApplication.translate("Form", u"output", None))
        self.Exit.setText(QCoreApplication.translate("Form", u"Exit", None))
        self.timeLabel.setText(QCoreApplication.translate("Form", u"TextLabel", None))
        self.callibrartionButton.setText(QCoreApplication.translate("Form", u"\u6821\u6b63\u6a21\u5f0f", None))
        self.realtimeButton.setText(QCoreApplication.translate("Form", u"\u5373\u6642\u91cf\u6e2c", None))
        self.diameterButton.setText(QCoreApplication.translate("Form", u"\u5916\u5f91\u91cf\u6e2c", None))
        self.thicknessButton.setText(QCoreApplication.translate("Form", u"\u539a\u5ea6\u91cf\u6e2c", None))
        self.normalText4.setText(QCoreApplication.translate("Form", u"\u984f\u8272\uff1a", None))
        self.colorTypeComboBox.setItemText(0, QCoreApplication.translate("Form", u"\u7070", None))
        self.colorTypeComboBox.setItemText(1, QCoreApplication.translate("Form", u"\u6a58", None))
        self.colorTypeComboBox.setItemText(2, QCoreApplication.translate("Form", u"\u85cd", None))
        self.colorTypeComboBox.setItemText(3, QCoreApplication.translate("Form", u"\u5176\u4ed6", None))

        self.normalText6.setText(QCoreApplication.translate("Form", u"\u578b\u865f\uff1a", None))
        self.pipelineTypeComboBox.setItemText(0, QCoreApplication.translate("Form", u"A", None))
        self.pipelineTypeComboBox.setItemText(1, QCoreApplication.translate("Form", u"B", None))
        self.pipelineTypeComboBox.setItemText(2, QCoreApplication.translate("Form", u"W", None))
        self.pipelineTypeComboBox.setItemText(3, QCoreApplication.translate("Form", u"E", None))
        self.pipelineTypeComboBox.setItemText(4, QCoreApplication.translate("Form", u"ES1", None))
        self.pipelineTypeComboBox.setItemText(5, QCoreApplication.translate("Form", u"R", None))
        self.pipelineTypeComboBox.setItemText(6, QCoreApplication.translate("Form", u"HIB", None))
        self.pipelineTypeComboBox.setItemText(7, QCoreApplication.translate("Form", u"HIW", None))

        self.normalText5.setText(QCoreApplication.translate("Form", u"\u5c3a\u5bf8\uff1a", None))
        self.pipelineDiameterComboBox.setItemText(0, QCoreApplication.translate("Form", u"65", None))
        self.pipelineDiameterComboBox.setItemText(1, QCoreApplication.translate("Form", u"80", None))
        self.pipelineDiameterComboBox.setItemText(2, QCoreApplication.translate("Form", u"90", None))
        self.pipelineDiameterComboBox.setItemText(3, QCoreApplication.translate("Form", u"100", None))
        self.pipelineDiameterComboBox.setItemText(4, QCoreApplication.translate("Form", u"125", None))
        self.pipelineDiameterComboBox.setItemText(5, QCoreApplication.translate("Form", u"150", None))
        self.pipelineDiameterComboBox.setItemText(6, QCoreApplication.translate("Form", u"200", None))

        self.videoLabel.setText(QCoreApplication.translate("Form", u"TextLabel", None))
        self.showImageLabel.setText("")
        self.statusLabel.setText(QCoreApplication.translate("Form", u"Status", None))
    # retranslateUi

