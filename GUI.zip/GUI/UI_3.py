# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'polo.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################
import sys
from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *
from PySide2.QtWidgets import QApplication,QMainWindow,QGraphicsView,QGraphicsScene
from PySide2.QtMultimedia import QMediaPlayer, QMediaContent
from PySide2.QtCore import Qt, QUrl
# from PySide2.QtCore import QUrl

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(1244, 735)
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.graphicsView = QGraphicsView(self.centralwidget)
        self.graphicsView.setObjectName(u"graphicsView")
        self.graphicsView.setGeometry(QRect(60, 150, 341, 221))
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QMenuBar(MainWindow)
        self.menubar.setObjectName(u"menubar")
        self.menubar.setGeometry(QRect(0, 0, 1244, 21))
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QStatusBar(MainWindow)
        self.statusbar.setObjectName(u"statusbar")
        MainWindow.setStatusBar(self.statusbar)
        self.toolBar = QToolBar(MainWindow)
        self.toolBar.setObjectName(u"toolBar")
        MainWindow.addToolBar(Qt.TopToolBarArea, self.toolBar)

        self.retranslateUi(MainWindow)

        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"MainWindow", None))
        self.toolBar.setWindowTitle(QCoreApplication.translate("MainWindow", u"toolBar", None))
    # retranslateUi

class VideoPlayer (QMainWindow):
    def __init__(self):
        super (VideoPlayer,self).__init__()
        self.ui=Ui_MainWindow()
        self.ui.setupUi(self)
        self.mediaPlayer = QMediaPlayer()
        # self.graphicsView = self.findChild(QGraphicsView,"graphicView")
        self.graphicsView = self.ui.graphicsView
        self.scene = QGraphicsScene()
        self.graphicsView.setScene(self.scene)
        videoFile=r"D:/tube_video.avi"
        mediaContent = QMediaContent(QUrl.fromLocalFile(videoFile))
        self.mediaPlayer.setMedia(mediaContent)
        self.mediaPlayer.setVideoOutput(self.graphicsView)
        self.mediaPlayer.play()

if __name__ == "__main__":
    app=QApplication(sys.argv)
    mainWindow = VideoPlayer()
    mainWindow.show()
    sys.exit(app.exec_())