# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'poloV2.ui'
##
## Created by: Qt User Interface Compiler version 5.15.8
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *  # type: ignore
from PySide2.QtGui import *  # type: ignore
from PySide2.QtWidgets import *  # type: ignore


class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(1441, 984)
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.screenshot_button = QPushButton(self.centralwidget)
        self.screenshot_button.setObjectName(u"screenshot_button")
        self.screenshot_button.setGeometry(QRect(740, 510, 75, 23))
        self.pipelineTypeComboBox = QComboBox(self.centralwidget)
        self.pipelineTypeComboBox.addItem("")
        self.pipelineTypeComboBox.addItem("")
        self.pipelineTypeComboBox.addItem("")
        self.pipelineTypeComboBox.addItem("")
        self.pipelineTypeComboBox.addItem("")
        self.pipelineTypeComboBox.addItem("")
        self.pipelineTypeComboBox.addItem("")
        self.pipelineTypeComboBox.addItem("")
        self.pipelineTypeComboBox.setObjectName(u"pipelineTypeComboBox")
        self.pipelineTypeComboBox.setGeometry(QRect(1060, 120, 111, 41))
        self.normalText6 = QLabel(self.centralwidget)
        self.normalText6.setObjectName(u"normalText6")
        self.normalText6.setGeometry(QRect(980, 127, 71, 31))
        font = QFont()
        font.setFamily(u"\u6a19\u6977\u9ad4")
        font.setPointSize(20)
        self.normalText6.setFont(font)
        self.csv_button = QPushButton(self.centralwidget)
        self.csv_button.setObjectName(u"csv_button")
        self.csv_button.setGeometry(QRect(970, 920, 75, 23))
        self.normalText4 = QLabel(self.centralwidget)
        self.normalText4.setObjectName(u"normalText4")
        self.normalText4.setGeometry(QRect(770, 124, 81, 41))
        self.normalText4.setFont(font)
        self.normalText5 = QLabel(self.centralwidget)
        self.normalText5.setObjectName(u"normalText5")
        self.normalText5.setGeometry(QRect(1180, 120, 91, 41))
        self.normalText5.setFont(font)
        self.test_button = QPushButton(self.centralwidget)
        self.test_button.setObjectName(u"test_button")
        self.test_button.setGeometry(QRect(820, 920, 75, 23))
        self.comboBox4 = QComboBox(self.centralwidget)
        self.comboBox4.addItem("")
        self.comboBox4.addItem("")
        self.comboBox4.setObjectName(u"comboBox4")
        self.comboBox4.setGeometry(QRect(260, 40, 81, 31))
        self.statusLabel = QLabel(self.centralwidget)
        self.statusLabel.setObjectName(u"statusLabel")
        self.statusLabel.setGeometry(QRect(750, 200, 621, 241))
        font1 = QFont()
        font1.setFamily(u"Arial")
        font1.setPointSize(72)
        self.statusLabel.setFont(font1)
        self.redButton = QPushButton(self.centralwidget)
        self.redButton.setObjectName(u"redButton")
        self.redButton.setGeometry(QRect(820, 840, 75, 23))
        self.redButton.setMaximumSize(QSize(75, 16777215))
        self.fullScreenButton = QPushButton(self.centralwidget)
        self.fullScreenButton.setObjectName(u"fullScreenButton")
        self.fullScreenButton.setGeometry(QRect(1140, 510, 75, 23))
        self.pipelineDiameterComboBox = QComboBox(self.centralwidget)
        self.pipelineDiameterComboBox.addItem("")
        self.pipelineDiameterComboBox.addItem("")
        self.pipelineDiameterComboBox.addItem("")
        self.pipelineDiameterComboBox.addItem("")
        self.pipelineDiameterComboBox.addItem("")
        self.pipelineDiameterComboBox.addItem("")
        self.pipelineDiameterComboBox.addItem("")
        self.pipelineDiameterComboBox.setObjectName(u"pipelineDiameterComboBox")
        self.pipelineDiameterComboBox.setGeometry(QRect(1270, 120, 111, 41))
        self.greenButton = QPushButton(self.centralwidget)
        self.greenButton.setObjectName(u"greenButton")
        self.greenButton.setGeometry(QRect(1130, 840, 75, 23))
        self.greenButton.setMaximumSize(QSize(75, 16777215))
        self.timeLabel = QLabel(self.centralwidget)
        self.timeLabel.setObjectName(u"timeLabel")
        self.timeLabel.setGeometry(QRect(770, 20, 611, 61))
        self.tableWidget = QTableWidget(self.centralwidget)
        self.tableWidget.setObjectName(u"tableWidget")
        self.tableWidget.setGeometry(QRect(740, 550, 641, 271))
        self.Exit = QPushButton(self.centralwidget)
        self.Exit.setObjectName(u"Exit")
        self.Exit.setGeometry(QRect(1130, 920, 75, 23))
        self.yellowButton = QPushButton(self.centralwidget)
        self.yellowButton.setObjectName(u"yellowButton")
        self.yellowButton.setGeometry(QRect(970, 840, 75, 23))
        self.yellowButton.setMaximumSize(QSize(75, 16777215))
        self.textEquipment = QLabel(self.centralwidget)
        self.textEquipment.setObjectName(u"textEquipment")
        self.textEquipment.setGeometry(QRect(20, 40, 401, 31))
        font2 = QFont()
        font2.setFamily(u"Times New Roman")
        font2.setPointSize(20)
        self.textEquipment.setFont(font2)
        self.colorTypeComboBox = QComboBox(self.centralwidget)
        self.colorTypeComboBox.addItem("")
        self.colorTypeComboBox.addItem("")
        self.colorTypeComboBox.addItem("")
        self.colorTypeComboBox.addItem("")
        self.colorTypeComboBox.setObjectName(u"colorTypeComboBox")
        self.colorTypeComboBox.setGeometry(QRect(860, 120, 111, 41))
        self.widget = QWidget(self.centralwidget)
        self.widget.setObjectName(u"widget")
        self.widget.setGeometry(QRect(30, 120, 661, 701))
        self.verticalLayout = QVBoxLayout(self.widget)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout = QHBoxLayout()
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.thicknessButton = QPushButton(self.widget)
        self.thicknessButton.setObjectName(u"thicknessButton")

        self.horizontalLayout.addWidget(self.thicknessButton)

        self.diameterButton = QPushButton(self.widget)
        self.diameterButton.setObjectName(u"diameterButton")

        self.horizontalLayout.addWidget(self.diameterButton)

        self.realtimeButton = QPushButton(self.widget)
        self.realtimeButton.setObjectName(u"realtimeButton")

        self.horizontalLayout.addWidget(self.realtimeButton)

        self.callibrartionButton = QPushButton(self.widget)
        self.callibrartionButton.setObjectName(u"callibrartionButton")

        self.horizontalLayout.addWidget(self.callibrartionButton)


        self.verticalLayout.addLayout(self.horizontalLayout)

        self.showImageLabel = QLabel(self.widget)
        self.showImageLabel.setObjectName(u"showImageLabel")

        self.verticalLayout.addWidget(self.showImageLabel)

        self.verticalSpacer = QSpacerItem(30, 40, QSizePolicy.Minimum, QSizePolicy.Fixed)

        self.verticalLayout.addItem(self.verticalSpacer)

        self.videoLabel = QLabel(self.widget)
        self.videoLabel.setObjectName(u"videoLabel")

        self.verticalLayout.addWidget(self.videoLabel)

        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QMenuBar(MainWindow)
        self.menubar.setObjectName(u"menubar")
        self.menubar.setGeometry(QRect(0, 0, 1441, 21))
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QStatusBar(MainWindow)
        self.statusbar.setObjectName(u"statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)

        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"MainWindow", None))
        self.screenshot_button.setText(QCoreApplication.translate("MainWindow", u"screen shot", None))
        self.pipelineTypeComboBox.setItemText(0, QCoreApplication.translate("MainWindow", u"A", None))
        self.pipelineTypeComboBox.setItemText(1, QCoreApplication.translate("MainWindow", u"B", None))
        self.pipelineTypeComboBox.setItemText(2, QCoreApplication.translate("MainWindow", u"W", None))
        self.pipelineTypeComboBox.setItemText(3, QCoreApplication.translate("MainWindow", u"E", None))
        self.pipelineTypeComboBox.setItemText(4, QCoreApplication.translate("MainWindow", u"ES1", None))
        self.pipelineTypeComboBox.setItemText(5, QCoreApplication.translate("MainWindow", u"R", None))
        self.pipelineTypeComboBox.setItemText(6, QCoreApplication.translate("MainWindow", u"HIB", None))
        self.pipelineTypeComboBox.setItemText(7, QCoreApplication.translate("MainWindow", u"HIW", None))

        self.normalText6.setText(QCoreApplication.translate("MainWindow", u"\u578b\u865f\uff1a", None))
        self.csv_button.setText(QCoreApplication.translate("MainWindow", u"output", None))
        self.normalText4.setText(QCoreApplication.translate("MainWindow", u"\u984f\u8272\uff1a", None))
        self.normalText5.setText(QCoreApplication.translate("MainWindow", u"\u5c3a\u5bf8\uff1a", None))
        self.test_button.setText(QCoreApplication.translate("MainWindow", u"input", None))
        self.comboBox4.setItemText(0, QCoreApplication.translate("MainWindow", u"2", None))
        self.comboBox4.setItemText(1, QCoreApplication.translate("MainWindow", u"6", None))

        self.statusLabel.setText(QCoreApplication.translate("MainWindow", u"Status", None))
        self.redButton.setText(QCoreApplication.translate("MainWindow", u"red", None))
        self.fullScreenButton.setText(QCoreApplication.translate("MainWindow", u"\u5168\u87a2\u5e55", None))
        self.pipelineDiameterComboBox.setItemText(0, QCoreApplication.translate("MainWindow", u"65", None))
        self.pipelineDiameterComboBox.setItemText(1, QCoreApplication.translate("MainWindow", u"80", None))
        self.pipelineDiameterComboBox.setItemText(2, QCoreApplication.translate("MainWindow", u"90", None))
        self.pipelineDiameterComboBox.setItemText(3, QCoreApplication.translate("MainWindow", u"100", None))
        self.pipelineDiameterComboBox.setItemText(4, QCoreApplication.translate("MainWindow", u"125", None))
        self.pipelineDiameterComboBox.setItemText(5, QCoreApplication.translate("MainWindow", u"150", None))
        self.pipelineDiameterComboBox.setItemText(6, QCoreApplication.translate("MainWindow", u"200", None))

        self.greenButton.setText(QCoreApplication.translate("MainWindow", u"green", None))
        self.timeLabel.setText(QCoreApplication.translate("MainWindow", u"TextLabel", None))
        self.Exit.setText(QCoreApplication.translate("MainWindow", u"Exit", None))
        self.yellowButton.setText(QCoreApplication.translate("MainWindow", u"yellow", None))
        self.textEquipment.setText(QCoreApplication.translate("MainWindow", u"Equipment Number", None))
        self.colorTypeComboBox.setItemText(0, QCoreApplication.translate("MainWindow", u"\u7070", None))
        self.colorTypeComboBox.setItemText(1, QCoreApplication.translate("MainWindow", u"\u6a58", None))
        self.colorTypeComboBox.setItemText(2, QCoreApplication.translate("MainWindow", u"\u85cd", None))
        self.colorTypeComboBox.setItemText(3, QCoreApplication.translate("MainWindow", u"\u5176\u4ed6", None))

        self.thicknessButton.setText(QCoreApplication.translate("MainWindow", u"\u539a\u5ea6\u91cf\u6e2c", None))
        self.diameterButton.setText(QCoreApplication.translate("MainWindow", u"\u5916\u5f91\u91cf\u6e2c", None))
        self.realtimeButton.setText(QCoreApplication.translate("MainWindow", u"\u5373\u6642\u91cf\u6e2c", None))
        self.callibrartionButton.setText(QCoreApplication.translate("MainWindow", u"\u6821\u6b63\u6a21\u5f0f", None))
        self.showImageLabel.setText("")
        self.videoLabel.setText(QCoreApplication.translate("MainWindow", u"TextLabel", None))
    # retranslateUi

