from PySide2.QtWidgets import QStyledItemDelegate, QStyle, QApplication, QStyleOptionViewItem
from PySide2.QtCore import Qt
from PySide2.QtGui import  QColor
from PySide2.QtCore import QUrl,QModelIndex
from PySide2.QtGui import QDesktopServices
from datetime import datetime

from PySide2.QtWidgets import QMainWindow
from PySide2.QtCore import Qt, QEvent
import os

class HyperlinkItemDelegate(QStyledItemDelegate):
    def __init__(self, parent=None):
        super(HyperlinkItemDelegate, self).__init__(parent)

    def paint(self, painter, option, index):
        options = QStyleOptionViewItem(option)
        self.initStyleOption(options, index)

        if options.text == "OK":
            painter.save()
            painter.setPen(QColor("black"))
            painter.fillRect(option.rect, QColor("green"))
            painter.setFont(options.font)
            painter.drawText(option.rect, Qt.AlignCenter, options.text)
            painter.restore()
        elif options.text == "NG":
            painter.save()
            painter.setPen(QColor("black"))
            painter.fillRect(option.rect, QColor("red"))
            painter.setFont(options.font)
            painter.drawText(option.rect, Qt.AlignCenter, options.text)
            painter.restore()
        else:
            super(HyperlinkItemDelegate, self).paint(painter, option, index)

    def editorEvent(self, event, model, option, index):
        if event.type() == event.MouseButtonRelease:
            if index.data() == "OK" or index.data() == "NG":
                
                time_column_index = QModelIndex(index.siblingAtColumn(0))

                timestamp = model.data(time_column_index, Qt.DisplayRole)
                parsed_timestamp = datetime.strptime(timestamp, "%m/%d %H:%M:%S")
                formatted_timestamp = parsed_timestamp.strftime("%m_%d_%H_%M_%S")

                # 根据列名选择文件夹
                column_name = model.headerData(index.column(), Qt.Horizontal, Qt.DisplayRole)
                if column_name == "厚度判定":
                    folder = "thicknessPic"
                elif column_name == "外徑判定":
                    folder = "diameterPic"
                else:
                    return False

                file_name = f"{formatted_timestamp}.png"
                file_path = os.path.join(folder, file_name)
                url = QUrl.fromLocalFile(os.path.abspath(file_path))
                QDesktopServices.openUrl(url)
                return True
        return False


class FullScreenWindow(QMainWindow):
    def __init__(self, video_label):
        super().__init__()

        self.setWindowFlags(Qt.WindowStaysOnTopHint)
        self.setWindowState(Qt.WindowFullScreen)
        self.installEventFilter(self)

        # 將 videoLabel 設置為全螢幕視窗的中心部件
        self.setCentralWidget(video_label)
        video_label.setScaledContents(True)
    def eventFilter(self, obj, event):
        if event.type() == QEvent.KeyPress and (event.key() == Qt.Key_Escape or event.key() == Qt.Key_Space):
            if obj == self:
                self.close()
                return True
        return super().eventFilter(obj, event)