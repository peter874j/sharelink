from concurrent.futures import thread
import sys

from PySide2.QtCore import Qt, QUrl

from PySide2.QtWidgets import QApplication, QMainWindow, QLabel,QVBoxLayout, QPushButton, QWidget, QFileDialog
from UI_0928 import Ui_MainWindow
from PySide2.QtWidgets import *
from PySide2.QtCore import *

from PySide2.QtGui import QImage,QPixmap
from PySide2.QtMultimediaWidgets import QGraphicsVideoItem
from PySide2.QtMultimedia import QMediaPlayer, QMediaContent

from PySide2.QtWidgets import QWidget, QLabel, QPushButton, QVBoxLayout,QApplication
import cv2

from PySide2.QtWidgets import QGraphicsDropShadowEffect
import csv

data= {
    
    'A':[65,80,90,100,125,150,200],
    "B":[60,100,125,150,200],
    "W":[65,80,100,125,150,200],
    "E":[65,80,100,125,150,200],
    "ES1":[80,100,125,150],
    "HIW":[80,100,125,150,200],
    "R":[125,150,200],
    
}



class MainWindow(QMainWindow):
    def __init__(self):
        super(MainWindow, self).__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.setup_control()
        self.installEventFilter(self)
        
    def setup_control(self):
        
        self.ui.videoLabel.setScaledContents(True) #自適應畫面大小
        self.ui.pipeDiameterLabel.setScaledContents(True)
        self.ui.pipeThickLabel.setScaledContents(True)

        self.timer = QTimer()
        self.timer.start(1)
        self.timer.timeout.connect(self.showtime)
        self.videoPath = "tube_video.mp4"
        self.imagePath = "label.png"
        self.setupCamera()
        # self.ui.change_buttom.clicked.connect(self.changeSpec)
        self.ui.screenshot_button.clicked.connect(self.captureLabelScreen)
        
        self.qpixmap = QPixmap()                     # 建立 QPixmap 物件
        self.qpixmap.load(self.imagePath)                # 讀取圖片
        # 也可以寫成下面這樣
        # qpixmap = QPixmap('mona.jpg')
        self.ui.pipeDiameterLabel.setPixmap(self.qpixmap)  
        self.ui.pipeThickLabel.setPixmap(self.qpixmap)  
        
        self.ui.statusLabel.setStyleSheet
        self.stylesheets = ["Red.qss", "Yellow.qss","Green.qss" ]
        self.ui.redButton.clicked.connect(self.redClick)
        self.ui.yellowButton.clicked.connect(self.yellowClick)
        self.ui.greenButton.clicked.connect(self.greenClick)
        
        self.statustimer = QTimer()
        # self.timer.timeout.connect(self.update)
        self.ui.test_button.clicked.connect(self.testText)
        self.ui.csv_button.clicked.connect(self.saveTocsv)
        #
        self.ui.fullScreenButton.clicked.connect(self.toggleFullScreen)

        #規格設定區
  
        #初始化顯示正常
        with open(self.stylesheets[2], "r") as file:
            stylesheet = file.read()
            self.ui.statusLabel.setText("系統正常")
            self.ui.statusLabel.setStyleSheet(stylesheet)
            self.ui.statusLabel.update()
        
        
        ### show image of the results
        self.ui.pipeDiameterLabel
        self.ui.pipeThickLabel

        self.flag1=False 
        # 初始化管型 QComboBox
        self.ui.pipelineTypeComboBox.clear()
        for pipe_type in data.keys():
            self.ui.pipelineTypeComboBox.addItem(pipe_type)

        # 当管型 QComboBox 更改时更新尺寸 QComboBox 的内容
        self.ui.pipelineTypeComboBox.currentIndexChanged.connect(self.update_sizes)

        # 初始化尺寸 QComboBox
        self.update_sizes(0)        
        self.ui.pipelineTypeComboBox.currentIndexChanged.connect(self.showMessageWindow1)
        self.ui.colorTypeComboBox.currentIndexChanged.connect(self.showMessageWindow2)
        self.ui.pipelineDiameterComboBox.currentIndexChanged.connect(self.showMessageWindow3)
        self.comboboxPreviousIndex1=0
        self.comboboxPreviousIndex2=0
        self.comboboxPreviousIndex3=0
        self.colotTpye=None
        self.pipelineType=None
        self.pipelineDiameter=None        
 
    def update_sizes(self, index):
        self.ui.pipelineDiameterComboBox.clear()
        for size in data[self.ui.pipelineTypeComboBox.currentText()]:
            self.ui.pipelineDiameterComboBox.addItem(str(size))
 
        
    def setupCamera(self):
        self.capture = cv2.VideoCapture(self.videoPath)
        self.timerVideo = QTimer()
        self.timerVideo.timeout.connect(self.displayVideoStream)
        self.timerVideo.start(30)
        
    def displayVideoStream(self):
        ret, self.frame = self.capture.read()

        if not ret:
            print("no image")
            self.timerVideo.stop()
            return

        self.frame = cv2.cvtColor(self.frame, cv2.COLOR_BGR2RGB)
        self.image = QImage(
            self.frame,
            self.frame.shape[1],
            self.frame.shape[0],
            self.frame.strides[0],
            QImage.Format_RGB888,
        )
        self.ui.videoLabel.setPixmap(QPixmap.fromImage(self.image))

        
    #顯示時間
    def showtime(self):
        time = QDateTime.currentDateTime()
        timedisplay = time.toString("yyyy-MM-dd hh:mm:ss dddd")
        self.ui.timeLabel.setText(timedisplay)
    
    def captureLabelScreen(self):
        screenshot = QPixmap.grabWidget(self.ui.videoLabel)
        screenshot.save("label.png","JPG")

    def redClick(self):
        with open(self.stylesheets[0], "r") as file:
            stylesheet = file.read()
            self.ui.statusLabel.setText("管材NG")
            self.ui.statusLabel.setStyleSheet(stylesheet)
            self.ui.statusLabel.update()

    def yellowClick(self):
        with open(self.stylesheets[1], "r") as file:
            stylesheet = file.read()
            self.ui.statusLabel.setText("系統異常")
            self.ui.statusLabel.setStyleSheet(stylesheet)
            self.ui.statusLabel.update()
    def greenClick(self):
        with open(self.stylesheets[2], "r") as file:
            stylesheet = file.read()
            self.ui.statusLabel.setText("系統正常")
            self.ui.statusLabel.setStyleSheet(stylesheet)
            self.ui.statusLabel.update()

    # def showMessageWindow1(self, index):
    #     if index > -1:  # 避免初始化時觸发

    #         messageBox = QMessageBox(self)
    #         messageBox.setWindowTitle("確認視窗")  # 將標題設置為 "確認視窗"
    #         messageBox.setText("目前規格：\n顏色：{}\n管型：{}\n規格：{}".format(self.ui.colorTypeComboBox.currentText(),
    #                                                                 self.ui.pipelineTypeComboBox.currentText(),
    #                                                                 self.ui.pipelineDiameterComboBox.currentText()))

    #         confirm_button = messageBox.addButton("確認", QMessageBox.AcceptRole)
    #         cancel_button = messageBox.addButton("取消", QMessageBox.RejectRole)
    #         messageBox.exec_()
    #         if messageBox.clickedButton() == cancel_button:
    #             # self.ui.pipelineTypeComboBox.currentIndexChanged.disconnect(self.showMessageWindow1)  # 断开连接
    #             self.ui.pipelineTypeComboBox.blockSignals(True)
    #             self.ui.pipelineTypeComboBox.setCurrentIndex(self.comboboxPreviousIndex1)
    #             self.ui.pipelineTypeComboBox.blockSignals(False)
    #             # self.ui.pipelineTypeComboBox.currentIndexChanged.connect(self.showMessageWindow1)  # 重新连接
    #         else:
    #             self.comboboxPreviousIndex1 = index
    #             self.colotTpye=self.ui.colorTypeComboBox.currentText()
    #             self.pipelineType=self.ui.pipelineTypeComboBox.currentText()
    #             self.pipelineDiameter=self.ui.pipelineDiameterComboBox.currentText()
    
    
                
        # print(self.pipelineType,self.colotTpye,self.pipelineDiameter)
    
    
    def showMessageWindow1(self, index):
        if index > -1:  # 避免初始化時觸发
            QTimer.singleShot(0, lambda: self.showMessage(index))

    def showMessage(self, index):
        messageBox = QMessageBox(self)
        messageBox.setWindowTitle("確認視窗")  # 將標題設置為 "確認視窗"
        messageBox.setText("目前規格：\n顏色：{}\n管型：{}\n規格：{}".format(self.ui.colorTypeComboBox.currentText(),
                                                                self.ui.pipelineTypeComboBox.currentText(),
                                                                self.ui.pipelineDiameterComboBox.currentText()))

        confirm_button = messageBox.addButton("確認", QMessageBox.AcceptRole)
        cancel_button = messageBox.addButton("取消", QMessageBox.RejectRole)
        messageBox.exec_()
        if messageBox.clickedButton() == cancel_button:
            self.ui.pipelineTypeComboBox.blockSignals(True)
            self.ui.pipelineTypeComboBox.setCurrentIndex(self.comboboxPreviousIndex1)
            self.ui.pipelineTypeComboBox.blockSignals(False)
        else:
            self.comboboxPreviousIndex1 = index
            self.colotTpye=self.ui.colorTypeComboBox.currentText()
            self.pipelineType=self.ui.pipelineTypeComboBox.currentText()
            self.pipelineDiameter=self.ui.pipelineDiameterComboBox.currentText()
                
    def showMessageWindow2(self, index):
        if index > -1:  # 避免初始化時觸发

            messageBox = QMessageBox(self)
            messageBox.setWindowTitle("確認視窗")  # 將標題設置為 "確認視窗"
            messageBox.setText("目前規格：\n顏色：{}\n管型：{}\n規格：{}".format(self.ui.colorTypeComboBox.currentText(),
                                                                    self.ui.pipelineTypeComboBox.currentText(),
                                                                    self.ui.pipelineDiameterComboBox.currentText()))

            confirm_button = messageBox.addButton("確認", QMessageBox.AcceptRole)
            cancel_button = messageBox.addButton("取消", QMessageBox.RejectRole)
            messageBox.exec_()
            if messageBox.clickedButton() == cancel_button:
                self.ui.colorTypeComboBox.currentIndexChanged.disconnect(self.showMessageWindow2)  # 断开连接
                self.ui.colorTypeComboBox.setCurrentIndex(self.comboboxPreviousIndex2)
                self.ui.colorTypeComboBox.currentIndexChanged.connect(self.showMessageWindow2)  # 重新连接
            else:
                self.comboboxPreviousIndex2 = index
                self.colotTpye=self.ui.colorTypeComboBox.currentText()
                self.pipelineType=self.ui.pipelineTypeComboBox.currentText()
                self.pipelineDiameter=self.ui.pipelineDiameterComboBox.currentText()              
        # print(self.pipelineType,self.colotTpye,self.pipelineDiameter)

    def showMessageWindow3(self, index):
        if index > -1:  # 避免初始化時觸发
            messageBox = QMessageBox(self)
            messageBox.setWindowTitle("確認視窗")  # 將標題設置為 "確認視窗"
            messageBox.setText("目前規格：\n顏色：{}\n管型：{}\n規格：{}".format(self.ui.colorTypeComboBox.currentText(),
                                                                    self.ui.pipelineTypeComboBox.currentText(),
                                                                    self.ui.pipelineDiameterComboBox.currentText()))

            confirm_button = messageBox.addButton("確認", QMessageBox.AcceptRole)
            cancel_button = messageBox.addButton("取消", QMessageBox.RejectRole)
            messageBox.exec_()
            if messageBox.clickedButton() == cancel_button:
                self.ui.pipelineDiameterComboBox.currentIndexChanged.disconnect(self.showMessageWindow3)  # 断开连接
                self.ui.pipelineDiameterComboBox.setCurrentIndex(self.comboboxPreviousIndex3)
                self.ui.pipelineDiameterComboBox.currentIndexChanged.connect(self.showMessageWindow3)  # 重新连接
            else:
                self.comboboxPreviousIndex3 = index
                self.colotTpye=self.ui.colorTypeComboBox.currentText()
                self.pipelineType=self.ui.pipelineTypeComboBox.currentText()
                self.pipelineDiameter=self.ui.pipelineDiameterComboBox.currentText()
        # print(self.pipelineType,self.colotTpye,self.pipelineDiameter)        


    def testText(self):
        self.ui.text1.append("123123123")

    def saveTocsv(self):
        text = self.ui.text1.toPlainText()
        lines = text.split("\n")
        file_path = "output.csv"
 
        with open(file_path, 'w', newline='', encoding='utf-8') as csvfile:
            csv_writer = csv.writer(csvfile)
            for line in lines:
                row_data = line.split(',')
                csv_writer.writerow(row_data)    
        self.ui.text1.clear()   


    def eventFilter(self, obj, event):
        if event.type() == QEvent.KeyPress and event.key() == Qt.Key_Escape:
            if self.windowState() & Qt.WindowFullScreen:
                self.setWindowState(Qt.WindowNoState)
                self.ui.videoLabel.setParent(self.ui.centralwidget)
                self.ui.videoLabel.setGeometry(QRect(70, 100, 521, 351))  
                self.ui.videoLabel.show()
            return True
        return super().eventFilter(obj, event)


    def toggleFullScreen(self):
        if self.windowState() & Qt.WindowFullScreen:
            self.setWindowState(Qt.WindowNoState)
            self.ui.videoLabel.setParent(self.ui.centralwidget)
            self.ui.videoLabel.setGeometry(QRect(70, 100, 521, 351))  
            self.ui.videoLabel.show()
        else:
            self.setWindowState(Qt.WindowFullScreen)
            self.ui.videoLabel.setParent(self)
            self.ui.videoLabel.setGeometry(self.geometry())
            self.ui.videoLabel.show()
            messageBoxScreen = QMessageBox(self)
            messageBoxScreen.setWindowTitle("系統提示")
            messageBoxScreen.setText("按下 ESC 鍵退出全螢幕模式")
            messageBoxScreen.setIcon(QMessageBox.Information)
            messageBoxScreen.setStandardButtons(QMessageBox.Ok)
            messageBoxScreen.exec_()
if __name__ == "__main__":
    app = QApplication (sys.argv)
    ui = MainWindow()
    ui.show()
    app.exec_()