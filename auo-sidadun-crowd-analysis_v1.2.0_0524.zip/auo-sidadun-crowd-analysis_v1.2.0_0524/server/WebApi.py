import requests
import threading
import time
import datetime
import queue


class WebApi:
    def __init__(
        self, initUrl, heatmapUrl, areaVisitorUrl, addAvgTimeUrl, modifyAvgTimeUrl, postInerval, logger
    ) -> None:
        self.initUrl = initUrl
        self.heatmapUrl = heatmapUrl
        self.areaVisitorUrl = areaVisitorUrl
        self.addAvgTimeUrl = addAvgTimeUrl
        self.modifyAvgTimeUrl = modifyAvgTimeUrl
        self.logger = logger
        self.areaNameList = ["1", "2", "3", "4", "5", "6", "7", "8"]
        self.postInerval = postInerval
        self.areaVisitorData, self.heatmapData, self.idDict = None, None, None
        self.avgStayTimeDict = dict()
        self.lastTimePost = 0
        self.IdPostQueue = queue.Queue()
        self.postThread = threading.Thread(target=self.__post_thread)
        self.postThread.start()

    def get_initial(self):
        """系統除重啟, 請求目前DB的最後一筆資料

        Returns:
            _type_: _description_
        """
        try:
            initData = requests.get(self.initUrl).json()
            dateToday = datetime.datetime.today().strftime("%Y%m%d")
            cntDay, noidList = int(initData[0]), initData[1]
            initDataDict, idList = dict(), list()

            ### 從入口展區ID更新日期確定當日人次最後更新日
            fence1Noid = noidList[0]
            cntDayupdateDate = fence1Noid.split("_")[0]

            ### 當天DB沒有人次資料
            if cntDayupdateDate != dateToday:
                initDataDict["cntDay"] = 0
            else:
                initDataDict["cntDay"] = cntDay

            for noid in noidList:
                ### DB 沒有該展區資料
                if noid == "":
                    id = 0
                else:
                    updateDate = noid.split("_")[0]
                    ### 該展區當天有資料
                    if updateDate == dateToday:
                        id = noid.split("_")[1]  ### noid 編碼規則: [日期]_[人記數]_[展區編號]
                        id = int(id) + 1  # 下一個 id 從 id+1 開始
                    else:
                        id = 0
                idList.append(id)
            initDataDict["idList"] = idList
            flag, msg = True, "ok"

        except Exception as e:
            self.logger.warning("無法取得DB的最後一筆資料: " + str(e))
            ### API 請求失敗重置資料
            initDataDict = dict({"cntDay": 0, "idList": list((0 for i in range(1, 9)))})

        return initDataDict

    def post_area_visitor(self, fenceCntDict):
        cntList = list()
        ### FIXME: YJChou 2023/02/23 查詢對應的區域名稱
        for fenceId, fenceCnt in fenceCntDict.items():
            cntList.append(fenceCnt)
        self.areaVisitorData = {"area": str(self.areaNameList), "count": str(cntList)}

    def post_heatmap(self, peopleCount, heatMapData, accCount):
        """_summary_

        Args:
            data (_type_): _description_
        """
        self.heatmapData = {"all_count": peopleCount, "acc_count": accCount, "data": heatMapData}

    def post_id(self, entryIdDict, exitIdDict):
        ### 有新資料才放入Queue, 避免塞車
        for fenceNum in exitIdDict.keys():
            exitId = exitIdDict[fenceNum]
            ### ID 上傳停留時間大於閾值的ID
            if len(exitId) != 0:
                self.IdPostQueue.put(exitIdDict)
                break
        # print("=" * 20)
        # print("IdPostQueue size: {}".format(self.IdPostQueue.qsize()))
        # print("=" * 20)

    def __post_thread(self):
        while True:
            ### 上傳熱力圖, 展區人數資料
            if self.areaVisitorData is None or self.heatmapData is None:
                time.sleep(0.1)
                continue

            try:
                timeNow = time.time()
                ### 避免頻繁上傳資料
                if timeNow - self.lastTimePost < self.postInerval:
                    time.sleep(0.1)
                    continue
                self.lastTimePost = time.time()
                t1 = time.time()
                r = requests.post(self.areaVisitorUrl, data=self.areaVisitorData)
                t2 = time.time()
                self.logger.debug("Post areaVisitorUrl finished in {:2f}s".format(t2 - t1))
                t1 = time.time()
                r = requests.post(self.heatmapUrl, data=self.heatmapData)
                t2 = time.time()
                self.logger.debug("Post heatmapUrl finished in {:2f}s".format(t2 - t1))
            except Exception as e:
                self.logger.error("Post areaVisitorUrl and heatmapUrl Error: " + str(e))

            if not self.IdPostQueue.empty():
                exitIdDict = self.IdPostQueue.get()
                ## 上傳 ID 進出時間資訊
                try:
                    timeNow = datetime.datetime.today()
                    date = timeNow.strftime("%Y%m%d")

                    ### 上傳停留時間大於閾值的資料
                    for fenceNum in exitIdDict.keys():
                        for exitId, info in exitIdDict[fenceNum].items():
                            ### noid 編碼規則: [日期]_[人記數]_[展區編號]
                            noid = date + "_" + str(exitId) + "_" + str(fenceNum)

                            data = dict(
                                {
                                    "noid": noid,
                                    "area_num": fenceNum,
                                    "time_in": info["startTime"],
                                    "time_out": info["endTime"],
                                    "duration": info["stayTime"],
                                }
                            )
                            t1 = time.time()
                            r = requests.post(self.addAvgTimeUrl, data=data)
                            t2 = time.time()
                            self.logger.debug("patch ID time_out finished in {:2f}s".format(t2 - t1))

                except Exception as e:
                    self.logger.error("Post entryIdDict and exitIdDict Error: " + str(e))


if __name__ == "__main__":
    heatmapUrl = "http://tw100043939.corpnet.auo.com:2022/API/GetHeatmap"
    areaVisitorUrl = "http://tw100043939.corpnet.auo.com:2022/API/GetAreaVisitor"
    webApi = WebApi(
        heatmapUrl=heatmapUrl,
        areaVisitorUrl=areaVisitorUrl,
        areaNameList=["展區1", "展區2", "展區3", "展區4", "展區5", "展區6", "展區7", "展區8"],
    )

    webApi.post_heatmap(peopleCount=1, heatMapData=list((100, 100, 60)), accCount=1)
    webApi.post_area_visitor(fenceCntDict={"1": 1, "2": 1, "3": 37, "4": 2, "5": 4, "6": 3, "7": 0, "8": 0})
