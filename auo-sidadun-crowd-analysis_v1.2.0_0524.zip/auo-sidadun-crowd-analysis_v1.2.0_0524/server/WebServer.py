import cv2
from flask import Flask, Response
import threading


class WebServer:
    def __init__(self, host="0.0.0.0", port=5000) -> None:
        self.host = host
        self.port = port
        self.streamImg = None
        self.app = Flask(__name__)
        self.__set_api()
        self.serverThread = threading.Thread(target=self.start_server)
        self.serverThread.start()

    def start_server(self):
        self.app.run(self.host, self.port, debug=False, use_reloader=False)

    def update_frame(self, streamImg):
        self.streamImg = streamImg

    def __set_api(self):
        @self.app.route("/stream")
        def get_frame():
            def stream_generator():
                while True:
                    if self.streamImg is not None:
                        encodedImage = self.__encoder(self.streamImg)
                        yield encodedImage

            return Response(stream_generator(), mimetype="multipart/x-mixed-replace; boundary=frame")

    def __encoder(self, img):
        (flag, encodedImage) = cv2.imencode(".jpg", img)  # 資料格式轉換為.jpg
        if flag:  # ensure the frame was successfully encoded
            encodedImage = b"--frame\r\n" b"Content-Type: image/jpeg\r\n\r\n" + bytearray(encodedImage) + b"\r\n"
        return encodedImage
