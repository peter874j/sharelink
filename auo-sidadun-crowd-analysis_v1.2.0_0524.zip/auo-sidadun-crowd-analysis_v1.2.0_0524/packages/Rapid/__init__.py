from .api import Detector
