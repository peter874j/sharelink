import json
import xml.etree.ElementTree as ET
import os
from os import walk
import math

def ro_box(orders, cx, cy, w, h, angle):
    ### 新增節點
    order6 = ET.SubElement(orders, 'object')
    ### 新增子節點
    suboder1 = ET.SubElement(order6, 'type')
    suboder1.text = "robndbox"
    suboder2 = ET.SubElement(order6, 'name')
    suboder2.text = "person"
    suboder3 = ET.SubElement(order6, 'pose')
    suboder3.text = "Unspecified"
    suboder4 = ET.SubElement(order6, 'truncated')
    suboder4.text = "0"
    suboder5 = ET.SubElement(order6, 'difficult')
    suboder5.text = "0"
    suboder6 = ET.SubElement(order6, 'robndbox')
    subodercx = ET.SubElement(suboder6, 'cx')
    subodercx.text = str(cx)
    subodercy = ET.SubElement(suboder6, 'cy')
    subodercy.text = str(cy)
    suboderw = ET.SubElement(suboder6, 'w')
    suboderw.text = str(w)
    suboderh = ET.SubElement(suboder6, 'h')
    suboderh.text = str(h)
    suboderangle = ET.SubElement(suboder6, 'angle')
    suboderangle.text = str(angle)

for root, dirs, files in walk('./json') :
    for josnName in files:
        folder = os.path.splitext(josnName)[0]
        repeat = 'First'
        with open('./json/{}.json'.format(folder)) as f:
            data = json.load(f)
        try:
            os.makedirs('./xml/{}/'.format(folder))
        # 檔案已存在的例外處理
        except FileExistsError:
            print("error")

        n = 0
        for i in range(len(data['annotations'])):
            filename = data['annotations'][i]['image_id']
            cx = data['annotations'][i]['bbox'][0]
            cy = data['annotations'][i]['bbox'][1]
            w = data['annotations'][i]['bbox'][2]
            h = data['annotations'][i]['bbox'][3]
            angle = data['annotations'][i]['bbox'][4]
            if float(angle) < 0:
                angle = str(float(angle) + 180)
            angle = str(float(angle)/180*math.pi)
            if os.path.isfile('xml/{}/{}.xml'.format(folder, filename)):
                pass
            else:
                if repeat != filename:
                    try:
                        ### 輸出 XML 原始資料
                        tree = ET.ElementTree(orders)
                        tree.write('xml/{}/{}.xml'.format(folder,repeat))
                    except:
                        print('First Labeling')

                    orders = ET.Element('annotation')
                    orders.set("verified", "no")
                    ### 新增節點
                    order1 = ET.SubElement(orders, 'folder')
                    order1.text = folder

                    ### 新增節點
                    order2 = ET.SubElement(orders, 'filename')
                    order2.text = filename

                    ### 新增節點
                    order3 = ET.SubElement(orders, 'path')
                    order3.text = r'\\mamcdatabase\Project\Efence\AuoHR\fisheyeDataset\WEPDTOF\frames\{}\{}.jpg'.format(folder, filename)

                    ### 新增節點
                    order3 = ET.SubElement(orders, 'source')
                    ### 新增子節點
                    suboder3_1 = ET.SubElement(order3, 'database')
                    suboder3_1.text = "Unknown"

                    ### 新增節點
                    order4 = ET.SubElement(orders, 'size')
                    ### 新增子節點
                    suboder4_1 = ET.SubElement(order4, 'width')
                    suboder4_1.text = "3840"
                    suboder4_2 = ET.SubElement(order4, 'height')
                    suboder4_2.text = "2160"
                    suboder4_3 = ET.SubElement(order4, 'depth')
                    suboder4_3.text = "3"

                    ### 新增節點
                    order5 = ET.SubElement(orders, 'segmented')
                    order5.text = "0"
                    ro_box(orders, cx, cy, w, h, angle)
                
                if repeat == filename:
                    n+= 1
                    print(repeat)
                    print(n)
                    ro_box(orders, cx, cy, w, h, angle)

                repeat = filename    
                if i == len(data['annotations']) - 1:
                    ### 輸出 XML 原始資料
                    tree = ET.ElementTree(orders)
                    tree.write('xml/{}/{}.xml'.format(folder, filename))