import sys
import os
import random
import shutil

sys.path.append("./")

from packages.FileEditor import load_json, save_json


### 確認標註的圖片都在資料夾內
def check_image_exist(imageList, imgFolderPath):
    existImgList = os.listdir(imgFolderPath)
    for imgFile in imageList:
        imgFileName = imgFile["file_name"]
        if imgFileName not in existImgList:
            raise (f"{imgFileName} is not in image folder!")


def make_dataset(choiceIdx, imgFolderPath, annotationFile, outputImgFoderPath, outputAnnotationFolderPath):
    os.makedirs(outputImgFoderPath, exist_ok=True)
    os.makedirs(outputAnnotationFolderPath, exist_ok=True)

    outputAnnotationFile = {"annotations": [], "images": [], "categories": annotationFile["categories"]}
    for idx in choiceIdx:
        imgFileName = annotationFile["images"][idx]["file_name"]
        imgId = annotationFile["images"][idx]["id"]
        outputAnnotationFile["images"].append(annotationFile["images"][idx])
        for anno in annotationFile["annotations"]:
            if anno["image_id"] == imgId:
                outputAnnotationFile["annotations"].append(anno)
        shutil.copy(os.path.join(imgFolderPath, imgFileName), os.path.join(outputImgFoderPath, imgFileName))
    save_json(outputAnnotationFile, os.path.join(outputAnnotationFolderPath, "annotation.json"))


def main(
    imgFolderPath,
    annotationFilePath,
    outputFoderPath,
    sets=["Valid", "Test", "Train"],
    valid_percent=0.1,
    test_percent=0.0,
    train_percent=0.9,
    isRandom=False,
):
    annotationFile = load_json(annotationFilePath)
    imageList = annotationFile["images"]
    annotationList = annotationFile["annotations"]
    check_image_exist(imageList, imgFolderPath)

    totalNum = len(imageList)
    validNum = int(totalNum * valid_percent)
    testNum = int(totalNum * test_percent)
    trainNum = totalNum - validNum - testNum
    setNum = [validNum, testNum, trainNum]

    idxList = [i for i in range(totalNum)]
    for i, setName in enumerate(sets):
        choiceIdx = []
        ### 隨機切分
        if isRandom:
            if i < len(sets) - 1:
                while len(choiceIdx) < setNum[i]:
                    tmpIdx = random.randint(0, len(idxList) - 1)
                    idx = idxList[tmpIdx]
                    idxList.pop(tmpIdx)
                    choiceIdx.append(idx)
            else:
                for idx in idxList:
                    choiceIdx.append(idx)
        ### 按順序切分
        else:
            choiceIdx = idxList[: setNum[i]]
            idxList = idxList[setNum[i] :]

        outputImgFoderPath = os.path.join(outputFoderPath, setName, "images")
        outputAnnotationFolderPath = os.path.join(outputFoderPath, setName, "annotations")
        make_dataset(choiceIdx, imgFolderPath, annotationFile, outputImgFoderPath, outputAnnotationFolderPath)


if __name__ == "__main__":
    ### 輸入團片資料夾
    imgFolderPath = r"D:\Users\YjChou\RAPiD-master\data\dataset\four_cam\SiDaDun\mamc\all\Images"

    ### 輸入標註.json檔
    annotationFilePath = (
        r"D:\Users\YjChou\RAPiD-master\data\dataset\four_cam\SiDaDun\mamc\all\Annotation\mamc_data.json"
    )

    ### 輸出資料夾
    outputFoderPath = r"D:\Users\YjChou\RAPiD-master\data\dataset\four_cam\SiDaDun\mamc"

    sets = ["valid", "test", "train"]  # 依序為 "Valid", "Test", "Train"
    ### 驗證集佔整體資料集比例
    valid_percent = 0.1
    ### 測試集佔整體資料集比例
    test_percent = 0.0
    ### 訓練集佔整體資料集比例
    train_percent = 0.9

    main(
        imgFolderPath,
        annotationFilePath,
        outputFoderPath,
        sets,
        valid_percent,
        test_percent,
        train_percent,
        isRandom=True,
    )
