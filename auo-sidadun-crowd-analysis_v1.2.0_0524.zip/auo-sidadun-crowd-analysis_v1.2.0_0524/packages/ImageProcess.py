from PIL import Image
import cv2


class ImageProcess:
    @staticmethod
    def cv2pil(imgCV):
        imgCV_RGB = cv2.cvtColor(imgCV, cv2.COLOR_BGR2RGB)
        imgPIL = Image.fromarray(imgCV_RGB)
        return imgPIL
