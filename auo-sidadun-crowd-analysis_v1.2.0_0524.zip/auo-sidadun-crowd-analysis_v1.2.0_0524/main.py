import os

os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"

from core.core import core


if __name__ == "__main__":
    core(debugMode=False)
