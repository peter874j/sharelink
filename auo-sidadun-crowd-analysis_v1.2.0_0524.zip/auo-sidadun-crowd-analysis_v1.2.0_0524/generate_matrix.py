import cv2
import numpy as np
import sys
import os

sys.path.append("./")
from packages.Calibrate import DistortionCorrection, AffineTransform


def get_affin_trans_matrix(srcPts, targetPts, matrixSavePath, matrixName):
    affineMatrix = AffineTransform.get_matrix(srcPts, targetPts, matrixSavePath, matrixName)
    return affineMatrix


def get_cam_distortion_corr_matix(imgPath, matrixSavePath, matrixName, visualize):
    img = cv2.imread(imgPath)
    DistortionCorrection.get_matrix(
        img, mode=3, matrixSavePath=matrixSavePath, matrixName=matrixName, visualize=visualize
    )


def get_all_cam_affin_trans_matrix(matrixSavePath):
    """_summary_

    Args:
        matrixSavePath (_type_): _description_
    Hint: Layout 的座標必須從x=0開始
    """
    ### For 西大墩
    # ### 畸變校正後的座標 (969*969) -> (2160*2160)
    # n = 2.23
    # src = [
    #     {"camId": "1", "Point": [(360 * n, 724 * n), (359 * n, 225 * n), (622 * n, 726 * n)]},
    #     {
    #         "camId": "2",
    #         "Point": [((110) * n, 181 * n), ((785 + 10) * n, 240 * n), ((790) * n, (651 - 50) * n)],
    #     },
    #     {
    #         "camId": "3_1",
    #         "Point": [((97 - 50) * n * n, 365 * n), ((110 - 10) * n, (240) * n), ((794 - 30) * n, 342 * n)],
    #     },
    #     {
    #         "camId": "3_2",
    #         "Point": [((115 - 10) * n, 473 * n), ((839 + 20) * n, 479 * n), ((817 + 20) * n, (687 + 80) * n)],
    #     },
    # ]

    # ### Layout座標 (5216*4106) -> (1044*822)
    # n = 0.2
    # target = [
    #     {"camId": "1", "Point": [(0 * n, 2177 * n), (0 * n, 0 * n), (981 * n, 2177 * n)]},
    #     {"camId": "2", "Point": [(0 * n, 0 * n), (3761 * n, 0 * n), (3761 * n, 1693 * n)]},
    #     {"camId": "3_1", "Point": [(0 * n, 873 * n), (0 * n, 0 * n), (3809 * n, 873 * n)]},
    #     {"camId": "3_2", "Point": [(0 * n, 0 * n), (5034 * n, 0 * n), (4801 * n, 1253 * n)]},
    # ]

    ### For showroom
    ### 畸變校正後的座標 (2160*2160)
    n = 1
    src = [
        {"camId": "1", "Point": [(387 * n, 415 * n), (1529 * n, 399 * n), (1567 * n, 1430 * n)]},
    ]
    ### Layout座標 (1044*822)
    n = 1
    target = [
        {"camId": "1", "Point": [((833 - 209) * n, 18 * n), ((833 - 209) * n, 804 * n), ((209 - 209) * n, 804 * n)]},
    ]

    for i in range(len(src)):
        srcPts = np.float32((src[i]["Point"]))
        targetPts = np.float32(target[i]["Point"])
        camId = src[i]["camId"]

        get_affin_trans_matrix(
            srcPts,
            targetPts,
            matrixSavePath=matrixSavePath,
            matrixName=f"cam{camId}_affine_matrix.npy",
        )


def main():
    # get_cam_distortion_corr_matix(
    #     imgPath=r"data\calibrate\fisheye\showroom_cam1.jpg",
    #     matrixSavePath=r"data\calibrate\matrix\distortion_tmp",
    #     matrixName="distortion_corr_matix",
    #     visualize=False,
    # )
    get_all_cam_affin_trans_matrix(matrixSavePath=r"data\calibrate\matrix\affine_tmp")


if __name__ == "__main__":
    main()
