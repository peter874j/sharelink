/data---/result
      |
      --/test_data---01.jpg
                   |-02.jpg
                   |-03.jpg
                   |-...
