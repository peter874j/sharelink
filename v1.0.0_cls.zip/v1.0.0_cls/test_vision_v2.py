import os
import json
import pytest
import cv2 as cv
import numpy as np

from modules.colombo_vision.vision_v2 import VisionV2

DATA_ROOT = "data/test_data"
RESULT_ROOT = "data/result"

os.makedirs(DATA_ROOT, exist_ok=True)
os.makedirs(RESULT_ROOT, exist_ok=True)

def load_imgs():
    return [(filename, cv.imread(os.path.join(DATA_ROOT, filename))) for filename in os.listdir(DATA_ROOT)]

def load_config():
    with open("config_black_tray_yellow_spacer.json", "r") as f:
        return json.load(f)["vision"]

@pytest.mark.parametrize("config, filename, img", [
    (load_config(), filename, img) for filename, img in load_imgs()
])

class TestVisionV2():
    def test_find_corners(self, config: dict, img: np.ndarray, filename: str):
        instance = VisionV2("positioning")
        instance.setup_config(config)
        instance.top_layer_class(img)
        success, corners = instance.find_corners(img)
        assert success == True
        assert isinstance(corners, dict)

        assert img is not None, f"Image {filename} is empty."
        save_path = os.path.join(RESULT_ROOT, filename.replace("raw", "result"))
        cv.imwrite(save_path, img)
        assert os.path.exists(save_path), f"Save image '{filename}' failed."
