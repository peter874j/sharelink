# colombo_vision_test
unit_test_for_colombo_vision

```
pytest test_vision_v2.py
```
