from ..interfaces.IRegion import IRegion

class LeftTopRegion(IRegion):
    def __init__(self, left_top: tuple, wh: tuple) -> None:
        w, h = wh
        super().__init__("left_top", left_top, w, h, (h - 1, w - 1), (0, 0))

class RightTopRegion(IRegion):
    def __init__(self, left_top: tuple, wh: tuple) -> None:
        w, h = wh
        super().__init__("right_top", left_top, w, h, (h - 1, 0), (0, w - 1))

class LeftBottomRegion(IRegion):
    def __init__(self, left_top: tuple, wh: tuple) -> None:
        w, h = wh
        super().__init__("left_bottom", left_top, w, h, (0, w - 1), (h - 1, 0))

class RightBottomRegion(IRegion):
    def __init__(self, left_top: tuple, wh: tuple) -> None:
        w, h = wh
        super().__init__("right_bottom", left_top, w, h, (0, 0), (h - 1, w - 1))