from ..interfaces.IModel import IModel

class WhiteSpacer630x530x20(IModel):
    def __init__(self) -> None:
        super().__init__(name="white_spacer_630x530x2",
                         model=[[0, 0], [487, 0], [0, 580], [487, 580]], 
                         center_bias=[0, 0], 
                         thickness=2.0)
    
    def is_model(self, hue: float) -> bool:
        return True if hue > 50 else False

class WhiteSpacer511x455x20(IModel):
    def __init__(self) -> None:
        super().__init__(name="white_spacer_511x455x2",
                         model=[[0, 0], [395, 0], [0, 491], [395, 491]], 
                         center_bias=[0, 0], 
                         thickness=2.0)
    
    def is_model(self, hue: float) -> bool:
        return True if hue > 100 else False

class BlueSpacer652x571x20(IModel):
    def __init__(self) -> None:
        super().__init__(name="blue_spacer_652x571x2", 
                         model=[[0, 0], [490, 0], [0, 560], [490, 560]], 
                         center_bias=[0, -40], 
                         thickness=2.0)
    
    def is_model(self, hue: float) -> bool:
        return True if hue > 90 else False

class YellowSpacer415x510x01(IModel):
    def __init__(self) -> None:
        super().__init__(name="yellow_spacer_510x415x2",
                         model=[[0, 0], [415, 0], [0, 510], [415, 510]], 
                         center_bias=[0, 0], 
                         thickness=0.1)
    
    def is_model(self, hue: float) -> bool:
        return True if hue > 35 and hue < 60 else False

class Panel610x511x12(IModel):
    def __init__(self) -> None:
        super().__init__(name="panel_610x511x1.2", 
                         model=[[0, 0], [511, 0], [0, 610], [511, 610]], 
                         center_bias=[0, 0], 
                         thickness=0.7)
    
    def is_model(self, hue: float) -> bool:
        return True if hue < 50 else False

class Panel511x415x005(IModel):
    def __init__(self) -> None:
        super().__init__(name="panel_511x415x0.05", 
                         model=[[0, 0], [415, 0], [0, 511], [415, 511]], 
                         center_bias=[0, 0], 
                         thickness=0.05)
    
    def is_model(self, hue: float) -> bool:
        return True if hue < 30 else False

class Dummy610x511x01(IModel):
    def __init__(self) -> None:
        super().__init__(name="dummy_610x511x0.1", 
                         model=[[0, 0], [511, 0], [0, 610], [511, 610]], 
                         center_bias=[0, 0], 
                         thickness=0.1)
    
    def is_model(self, hue: float) -> bool:
        return True if hue > 90 else False

class Unknown(IModel):
    def __init__(self) -> None:
        super().__init__(name="unknown", 
                         model=[[0, 0], [0, 0], [0, 0], [0, 0]], 
                         center_bias=[0, 0], 
                         thickness=0.0)
    
    def is_model(self, hue: float) -> bool:
        return False