from ..interfaces.IAbstractFactory import IAbstractFactory
from ..colombo_vision.enum import *

class RegionCreator(IAbstractFactory):
    def _create_module(self, module_name: str):
        from ..models.Region import LeftTopRegion, RightTopRegion, LeftBottomRegion, RightBottomRegion

        if module_name == "left_top":
            module = LeftTopRegion
        elif module_name == "right_top":
            module = RightTopRegion
        elif module_name == "left_bottom":
            module = LeftBottomRegion
        elif module_name == "right_bottom":
            module = RightBottomRegion
        else:
            module = None

        return module

class ModelCreator(IAbstractFactory):
    def _create_module(self, module_name: int):
        from ..models.Model import WhiteSpacer630x530x20, WhiteSpacer511x455x20, BlueSpacer652x571x20, YellowSpacer415x510x01, Panel610x511x12, Panel511x415x005, Dummy610x511x01, Unknown

        if module_name == ModelType.SPACER_WHITE_630x530x20.value:
            module = WhiteSpacer630x530x20
        elif module_name == ModelType.SPACER_WHITE_511x455x20.value:
            module = WhiteSpacer511x455x20
        elif module_name == ModelType.SPACER_BLUE_652x571x20.value:
            module = BlueSpacer652x571x20
        elif module_name == ModelType.SPACER_YELLOW_415x510x01.value:
            module = YellowSpacer415x510x01
        elif module_name == ModelType.PANEL_610x511x12.value:
            module = Panel610x511x12
        elif module_name == ModelType.PANEL_511x415x005.value:
            module = Panel511x415x005
        elif module_name == ModelType.DUMMY_610x511x01.value:
            module = Dummy610x511x01
        else:
            module = Unknown

        return module