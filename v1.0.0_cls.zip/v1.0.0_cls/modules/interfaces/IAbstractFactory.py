import numpy as np

from abc import ABC, abstractmethod

class IAbstractFactory(ABC):    
    @abstractmethod
    def _create_module(self, module_name: str):
        """
        Instantiate target module & return the module.

        """
        pass
    
    def set_module(self, module_name):
        """
        Setup target module, 'create_module()' have to be implemented.

        """
        module = self._create_module(module_name)

        if np.any(module): # module is exist
            return module
        else:
            return None