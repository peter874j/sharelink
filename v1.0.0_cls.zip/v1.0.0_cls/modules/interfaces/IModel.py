import cv2 as cv
import numpy as np

from abc import ABC, abstractmethod


class IModel(ABC):
    def __init__(self, name, model, center_bias, thickness) -> None:
        self.__name = name
        self.__model = np.array(model, dtype=np.float32)
        self.__center_bias = center_bias
        self.__center = np.array([[self.__model[1][0] / 2 + self.__center_bias[0],
                                   self.__model[2][1] / 2 + self.__center_bias[1]]])
        
        self.__points = np.append(self.__model, self.__center, axis=0)
        self.__points = np.append(self.__points, np.expand_dims(np.ones(self.__points.shape[0]), axis=1), axis=1)
        self.__thickness = thickness # mm

    @abstractmethod
    def is_model(self, hue: float) -> bool:
        """
        Identify model type by hue in HSV color model.

        """
        pass

    def get_perspective_transform(self, corners: np.array):
        """
        Get perspective transform matrix and calculate corners after transformed.
        
        """
        H = cv.getPerspectiveTransform(self.__model, corners)
        # :corners is order as left-top, right-top, left-bottom, right-bottom and center
        corners = self.__get_transform_result(H)

        return H, corners

    def __get_transform_result(self, H: np.array) -> list:
        """
        Calculate corners and center after perspective transform.

        """
        return [tuple(H.dot(point.T)[:2] / H.dot(point.T)[2]) for point in self.__points]

    @property
    def name(self):
        return self.__name

    @property
    def model(self):
        return self.__model
    
    @property
    def center_bias(self):
        return self.__center_bias
    
    @property
    def thickness(self):
        return self.__thickness