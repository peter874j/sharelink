import cv2 as cv
import numpy as np

from typing import Tuple
from abc import ABC


class IRegion(ABC):
    def __init__(self, region_type, left_top: tuple, w: int, h: int, interest_class: tuple, image_corner: tuple) -> None:
        self.__type = region_type
        self.__left_top = left_top # left top corner (x, y) in raw image
        self.__w = w
        self.__h = h
        self.__interest_class = interest_class # (y, x)
        self.__image_corner = image_corner # (y, x)

    def __detect_corner(self, binary):
        intersection_point = (-1, -1)
        vertical_lines, horizontal_lines, intersection_points = [], [], []

        edges = cv.Canny(binary, 50, 150, apertureSize=3)
        lines = cv.HoughLines(edges, 1, np.pi/180, threshold=60)

        if lines is not None:
            for line in lines:
                _, theta = line[0]
                thred = np.deg2rad(10)
                if abs(theta - np.deg2rad(0)) < thred or abs(theta - np.deg2rad(180)) < thred:
                    vertical_lines.append(line)
                elif abs(theta - np.deg2rad(90)) < thred or abs(theta - np.deg2rad(270)) < thred:
                    horizontal_lines.append(line)

            for v in vertical_lines:
                for h in horizontal_lines:
                    intersection_point = self.__calculate_intersection(v[0], h[0])
                    intersection_points.append(intersection_point)

        return np.mean(intersection_points, axis=0, dtype=np.int16) if len(intersection_points) != 0 else None

    def __calculate_intersection(self, line1, line2):
        rho1, theta1 = line1
        rho2, theta2 = line2

        A = np.array([
            [np.cos(theta1), np.sin(theta1)],
            [np.cos(theta2), np.sin(theta2)]
        ])

        b = np.array([[rho1], [rho2]])

        # Calculate the intersection point
        x0, y0 = np.linalg.solve(A, b)
        x0, y0 = int(np.round(x0)), int(np.round(y0))

        return ([x0, y0])

    def __max_pooling(self, image, kernel_size):
        rows, cols = image.shape
        pooled_rows = rows // kernel_size
        pooled_cols = cols // kernel_size
        pooled_image = np.zeros((pooled_rows, pooled_cols), dtype=np.uint8)

        for r in range(pooled_rows):
            for c in range(pooled_cols):
                pool_region = image[r * kernel_size : (r + 1) * kernel_size, c * kernel_size : (c + 1) * kernel_size]
                pooled_image[r, c] = np.amax(pool_region)
        
        return pooled_image

    def __upscale(self, image, scale_factor):
        rows, cols = image.shape
        upscaled_rows = rows * scale_factor
        upscaled_cols = cols * scale_factor
        upscaled_image = np.zeros((upscaled_rows, upscaled_cols), dtype=np.uint8)

        for r in range(rows):
            for c in range(cols):
                upscaled_image[r * scale_factor : (r + 1) * scale_factor, c * scale_factor : (c + 1) * scale_factor] = image[r, c]
        
        return upscaled_image

    def get_POI(self, img: np.array, classes: int = 3) -> Tuple[np.array, tuple]:
        """
        Find out interest point in ROI (POI means Point of Interest).

        In pannel case, corner is detected by shortest distance between image corner and pannel area.

        Corner+------+
              |   *--|
              |   | p|
              +------+
                Image

        """
        # Reset success status
        is_success = False
        result_corner = None

        # Image preprocessing
        hsv_image = cv.cvtColor(img, cv.COLOR_BGR2HSV)
        hsv_image[:, :, 1] = np.clip(2.0 * hsv_image[:, :, 1], 0, 255)
        img = cv.cvtColor(hsv_image, cv.COLOR_HSV2BGR)

        # Segmentation using K-means
        img = self.get_region(img)
        _, label, center = self.kmeans(np.float32(img.reshape((-1, 3))), classes)
        img = center[label.flatten()].reshape((img.shape)).astype(np.uint8)
        # Classify interest area   
        gray = np.where(img == img[self.__interest_class], 255, 0).astype(np.uint8)
        gray = cv.cvtColor(gray, cv.COLOR_BGR2GRAY)
        _, binary = cv.threshold(gray, 254, 255, cv.THRESH_BINARY)
        
        # kernel_size = 2
        # pooled_image = self.__max_pooling(binary, kernel_size)
        # pooled_image = self.__max_pooling(pooled_image, kernel_size)
        # pooled_image = self.__upscale(pooled_image, kernel_size)
        # binary = self.__upscale(pooled_image, kernel_size)

        # Clean noise
        kernel = cv.getStructuringElement(cv.MORPH_RECT, (7, 7))
        binary = cv.erode(binary, kernel)
        binary = cv.dilate(binary, kernel)
        
        contours, _ = cv.findContours(binary, cv.RETR_TREE, cv.CHAIN_APPROX_SIMPLE)
        centroids = [(cv.moments(cnt)['m10'] / (cv.moments(cnt)['m00'] + 1e-16), 
                      cv.moments(cnt)['m01'] / (cv.moments(cnt)['m00'] + 1e-16)) for cnt in contours]

        try:
            if len(centroids) > 0: 
                closest = np.argmin([(c[0] - self.__interest_class[1]) ** 2 + (c[1] - self.__interest_class[0]) ** 2 
                                    for c in centroids if binary[(int(c[1]), int(c[0]))] != 0])
                for i, contour in enumerate(contours):
                    if i != closest:
                        cv.drawContours(binary, [contour], -1, color=(0, 0, 0), thickness=cv.FILLED)
                    else:
                        cv.drawContours(binary, [contour], -1, color=(255, 255, 255), thickness=cv.FILLED)
        except:
            print("~~~~~~~~~")
            pass

        # result_img = cv.cvtColor(binary, cv.COLOR_GRAY2BGR)
        result_img = img.copy()

        corner = self.__detect_corner(binary)
        if corner is not None:
            cv.circle(result_img, tuple(corner), 1, (0, 0, 255), 2)
            result_corner  = (corner[0] + self.__left_top[0], corner[1] + self.__left_top[1])
            is_success = True
        
        else:
            # Get all index of pannel area (white area)
            pannel_area_index = np.argwhere(binary == 255)
            # Calculate all distance between image corner and pannel area
            dists = np.sum(np.square(self.__image_corner - pannel_area_index), axis=1)
            if not dists.size: # if dists is empty
                result_corner = None
            else:
                is_success = True
                # Get minimum
                pannel_corner = pannel_area_index[np.where(dists == np.min(dists))][0][::-1]
                # Transform local position to raw image positioin
                cv.circle(result_img, tuple(pannel_corner), 1, (0, 0, 255), 2)
                result_corner  = (pannel_corner[0] + self.__left_top[0], pannel_corner[1] + self.__left_top[1])

        return is_success, result_img, result_corner

    def get_region(self, img: np.array) -> np.array:
        # Check if region is out of bounding
        bbox_size = min(img.shape[:2]) // 5
        
        if self.__left_top[0] > img.shape[1]:
            self.__left_top = (img.shape[1] - bbox_size, self.__left_top[1])
            self.__w = bbox_size
        if self.__left_top[1] > img.shape[0]:
            self.__left_top = (self.__left_top[0], img.shape[0] - bbox_size)
            self.__h = bbox_size
        
        return img[self.__left_top[1]:self.__left_top[1] + self.__h, self.__left_top[0]:self.__left_top[0] + self.__w]

    def kmeans(self, data, k, attempts=10, flags=cv.KMEANS_PP_CENTERS):
        criteria = (cv.TERM_CRITERIA_EPS + cv.TERM_CRITERIA_MAX_ITER, 30, 1.0)
        ret, label, center = cv.kmeans(data, k, None, criteria, attempts, flags)
        return ret, label, center
    
    def get_distance(self, corner):
        corner = tuple(c - self.__left_top[i] for i, c in enumerate(corner))
        return np.linalg.norm(np.array(corner) - np.array([self.__w / 2, self.__h / 2]))

    @property
    def type(self):
        return self.__type

    @property
    def left_top(self):
        return self.__left_top
    
    @property
    def w(self):
        return self.__w
    
    @property
    def h(self):
        return self.__h