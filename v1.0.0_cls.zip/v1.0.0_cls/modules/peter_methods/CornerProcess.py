import cv2
import numpy as np
import statistics
from sklearn.decomposition import PCA
from .ImageProcess import *

def pca_best_fit_line(coords):
    """1.透過多點擬合直線
       2.尋找直線方程式
    Args:
        coords (list): 眾數點位座標

    Returns:
        slope (float), intercept (float): 一組斜率及截距
    """
    coords = np.array(coords)
    pca = PCA(n_components=1)
    pca.fit(coords)

    ### 找不到直線方程式排除
    if pca.components_[0][1]==0 or pca.components_[0][0]==0:
        return None, None
    
    slope = pca.components_[0][1] / pca.components_[0][0]
    intercept = np.mean(coords[:, 1]) - slope * np.mean(coords[:, 0])
    
    return slope, intercept

def get_linear_equation_by_lines(img, coords, mode = None):
    """1.尋找四條邊
        2.尋找直線方程式

    Args:
        img (img): 原始圖象
        coords (list): 眾數點位座標
        mode (string): 垂直、水平模式

    Returns:
        slope (float), intercept (float): 一組斜率及截距
    """
    ### 取得img長、高
    height, width = img.shape[:2]

    ### 取得最佳擬合直線
    slope, intercept = pca_best_fit_line(coords)

    if slope != None and intercept != None:
        ### 尋找直線方程式起點及終點
        if mode == 'V':
            start_x, end_x = 0, width - 1
            start_y, end_y = int(intercept + slope * start_x), int(intercept + slope * end_x)
        else:
            start_y, end_y = 0, height - 1
            start_x, end_x = int((start_y - intercept) / slope), int((end_y - intercept) / slope)

        # cv2.line(img, (start_x, start_y), (end_x, end_y), (0, 255, 0), 2) #驗證用
        # show_img("line", img)
    
    return slope, intercept

def get_linear_equation_by_points(img, pointsA, pointsB, modeValue, mode = None):
    """1.尋找所有眾數點位
       2.尋找所有邊的直線方程式

    Args:
        img (img): 原始圖象
        pointsA (list): pointsA 點位陣列
        pointsB (list): pointsB 點位陣列
        modeValue (int): AB 距離眾數
        mode (string): 垂直、水平模式

    Returns:
        slopeA (float), interceptA (float), slopeB (float), interceptB (float): 兩組斜率及截距
    """
    ### 尋找眾數的index
    modeValueIndexes = [index for index, value in enumerate(pointsB - pointsA) if value == modeValue]
    CoordsA =[]
    CoordsB =[]

    ### 計算該眾數點位斜率及截距
    if mode == 'V':
        ### 紀錄長度為眾數的A、B點位座標
        for i in modeValueIndexes:
            # cv2.circle(img, (i + 1, pointsA[i]), 3, (0, 0, 255), 3)  #驗證用
            # cv2.circle(img, (i + 1, pointsB[i]), 3, (0, 0, 255), 3)  #驗證用
            CoordsA.append([i + 1, pointsA[i]])
            CoordsB.append([i + 1, pointsB[i]])
        # show_img("imgV", img)
        slopeA, interceptA = get_linear_equation_by_lines(img, CoordsA, mode = 'V')
        slopeB, interceptB = get_linear_equation_by_lines(img, CoordsB, mode = 'V')
    else:
        for i in modeValueIndexes:
            # cv2.circle(img, (pointsA[i], i + 1), 3, (255, 0, 255), 3)  #驗證用
            # cv2.circle(img, (pointsB[i], i + 1), 3, (255, 0, 255), 3)  #驗證用
            CoordsA.append([pointsA[i], i + 1])
            CoordsB.append([pointsB[i], i + 1])
        # show_img("imgH", img)
        slopeA, interceptA = get_linear_equation_by_lines(img, CoordsA, mode = 'H')
        slopeB, interceptB = get_linear_equation_by_lines(img, CoordsB, mode = 'H')

    return slopeA, interceptA, slopeB, interceptB

def get_board_distances(boardImg, mode, clsMode = False):
    """取得基板長邊、短邊所有座標點及垂直、水平距離

    Args:
        boardImg (img): 二值化影像(基板範圍)
        mode (string): 垂直、水平模式

    Returns:
        pointsA (list), pointsB (list), distances (list): pointsA 點位陣列、pointsB 點位陣列、兩點位距離陣列
    """
    ### 取得Mask長、高
    height, width = boardImg.shape[:2]

    ### 轉換為二值圖像，將非0（非黑色）元素全部設置為255
    _, binaryMask = cv2.threshold(boardImg, 0, 255, cv2.THRESH_BINARY)

    ### 定義垂直及水平模式的參數
    if mode == 'V':
        axis = 0
        length = height
    else:
        axis = 1
        length = width

    ### 尋找內縮第一個白點座標
    pointsA = binaryMask.argmax(axis = axis)
    pointsB = length - 1 - np.flip(binaryMask, axis = axis).argmax(axis = axis)

    ### 遇不到白點時補全範例
    hasWhitePoint = (binaryMask.max(axis = axis) > 0)
    pointsA[~hasWhitePoint] = length  # 遇不到白點時頂部索引設置為height方便計算距離
    pointsB[~hasWhitePoint] = 0    # 遇不到白點時底部索引設置為0方便計算距離

    ### 計算A白點到B白點的距離
    AtoBDistances = pointsB - pointsA

    ### 過濾結果為負的距離 
    distances = [num for num in AtoBDistances if num >= 0]
    if not clsMode:
        distances = [num for num in AtoBDistances if num >= 800]  # 20230814 WYLee 素面反光卡控

    return pointsA, pointsB, distances

def trans_form_coords(pts, biasPt):
    """小圖座標投射回大圖

    Args:
        pts (list): (x, y), 小圖座標
        biasPt (list): [xbias, ybias], crop偏移植

    Returns:
        mapPts (list): [[x1, y1], [x2, y2], [x3, y3], [x4, y4]]
    """
    x ,y = pts
    mapPts = (x + biasPt[0], y + biasPt[1])
    return mapPts

def find_intersection(m1, b1, m2, b2):
    """利用兩直線方程式取得交點

    Args:
        m1 (float): 斜率1
        b1 (float): 截距1
        m2 (float): 斜率2
        b2 (float): 截距2

    Returns:
        x (int), y (int) : (x, y), 交點座標 
    """
    if m1 == m2:
        return None
    x = (b2 - b1) / (m1 - m2)
    y = m1 * x + b1
    return (round(x), round(y))

def get_corner(origImg, binImg):
    """尋找四角座標

    Args:

        binImg (img): 二值化影像

    Returns:
        box: [[x1, y1], [x2, y2], [x3, y3], [x4, y4]], (0:左下 1:左上 2:右上 3:右下)
    """
    ### 黑白對調
    binImg = 255 - binImg

    ### 建立遮罩供繪製基板位置
    mask = np.zeros_like(binImg)

    ### 尋找所有外接矩形
    contours, _ = cv2.findContours(binImg, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

    ### 尋找最大外接輪廓
    maxContour = max(contours, key=cv2.contourArea)

    ### 繪製最大外接輪廓(基板位置)
    boardImg = cv2.drawContours(mask, [maxContour], 0, (255, 255, 255), -1)
    # show_img("boardImg0", boardImg)
    # cv2.imwrite(imgFile.replace('img', 'b'), boardImg)
    kernel = np.ones((7,7), np.uint8)
    boardImg = cv2.morphologyEx(boardImg, cv2.MORPH_OPEN, kernel) 
    # show_img("boardImg", boardImg)
    ### 取得基板上方及下方短邊所有座標點、垂直距離
    topPoints, bottomPoints, VDist = get_board_distances(boardImg, mode = 'V')
    ### 取得基板左方及右方長邊所有座標點、水平距離
    leftPoints, rightPoints, HDist = get_board_distances(boardImg, mode = 'H')
    ### 取得基板上方及下方短邊斜率、截距
    slopeT, interceptT, slopeB, interceptB = get_linear_equation_by_points(origImg, topPoints, bottomPoints, statistics.mode(VDist), mode = 'V')
    ### 取得基板左方及右方長邊斜率、截距
    slopeL, interceptL, slopeR, interceptR = get_linear_equation_by_points(origImg, leftPoints, rightPoints, statistics.mode(HDist), mode = 'H')
    # show_img('img', origImg)
    if None not in [slopeT, interceptT, slopeB, interceptB, slopeL, interceptL, slopeR, interceptR]:
        lLBoardPts = find_intersection(slopeT, interceptT, slopeL, interceptL)
        uLBoardPts = find_intersection(slopeB, interceptB, slopeL, interceptL)
        uRBoardPts = find_intersection(slopeB, interceptB, slopeR, interceptR)
        lRBoardPts = find_intersection(slopeT, interceptT, slopeR, interceptR)
        return [lLBoardPts, uLBoardPts, uRBoardPts, lRBoardPts]
    else:
        return None