import cv2
import numpy as np

def show_stack_imgs(strID, imgs, size=(648, 486)):

    mergeImg = np.hstack(imgs)
    reImg = cv2.resize(mergeImg, size, interpolation=cv2.INTER_AREA) 
    # cv2.imwrite(strID+'.jpg', reImg)
    cv2.imshow(strID, reImg)
    cv2.waitKey(0)
    # cv2.destroyAllWindows()

def order_points(pts):
    """排序座標點: 左下點起始順時針

    Args:
        pts (list): [[x1, y1], [x2, y2], [x3, y3], [x4, y4]]

    Returns:
        orderPts (list): [[x1, y1], [x2, y2], [x3, y3], [x4, y4]]
    """

    sortX = pts[np.argsort(pts[:, 0]), :]
    left = sortX[:2, :]
    right = sortX[2:, :]
    left = left[np.argsort(left[:,1])[::-1], :]
    right = right[np.argsort(right[:,1]), :]
    return np.concatenate((left, right), axis=0)

def crop_corner_img(img):
    ### 裁切8個小圖: 左下 / 左上 / 右上 / 右下 / 上 / 下 / 左 / 右
    ### format: img[y:y+h, x:x+w]
    lLImg = img[1520:1920, 450:770]
    uLImg = img[35:435, 450:770]
    uRImg = img[35:435, 1840:2160]
    lRImg = img[1520:1920, 1840:2160] # 320x400
    return lLImg, uLImg, uRImg, lRImg

def get_roi_img(crop_imgs, crop_area):
    ### 在小圖中靠基板位置裁切ROI圖, 統計其直方圖分布, 匹配小圖中的基板

    roiULImg = crop_imgs[0][-crop_area[1]:, -crop_area[0]:]
    roiURImg = crop_imgs[1][-crop_area[1]:, 0:crop_area[0]]
    roiLLImg = crop_imgs[2][0:crop_area[1], -crop_area[0]:]
    roiLRImg = crop_imgs[3][0:crop_area[1], 0:crop_area[0]]
    roiImg = np.vstack([roiLLImg, roiULImg, roiURImg, roiLRImg])
    return roiImg

def get_max_area_box(binImg):
    """取得輪廓最大外接矩形座標

    Args:
        binImg (img): 二值化影像

    Returns:
        box: [[x1, y1], [x2, y2], [x3, y3], [x4, y4]], (0:左下 1:左上 2:右上 3:右下)
    """

    ### 計算二值影像輪廓
    contours, hierarchy = cv2.findContours(binImg, cv2.RETR_TREE, cv2.CHAIN_APPROX_NONE)
    areas = []
    for c in range(len(contours)):
        areas.append(cv2.contourArea(contours[c]))
    maxID = areas.index(max(areas))

    ### 取得輪廓最小外接矩陣 (中心點座標, 寬高, 旋轉角度)
    maxContour = contours[maxID]
    maxRect = cv2.minAreaRect(maxContour)
    
    ### 取得外接矩形的四點座標 
    box = cv2.boxPoints(maxRect)
    box = np.intp(box)  # 座標取整數
    box = order_points(box) # 排序座標點
    return box

def get_board_coords(roiImg, tarImg):
    """直方圖反向投射

    Args:
        roiImg (img): 參考影像
        tarImg (img): 目標影像

    Returns:
        pts (list): [[x1, y1], [x2, y2], [x3, y3], [x4, y4]]
    """
    hsvROIImg = cv2.cvtColor(roiImg, cv2.COLOR_BGR2HSV)

    hsvTarImg = cv2.cvtColor(tarImg, cv2.COLOR_BGR2HSV)
    ### calculating object histogram
    roiHist = cv2.calcHist([hsvROIImg], [0, 1], None, [180, 256], [0, 180, 0, 256])
    ### normalize histogram and apply backprojection 規一化為 0~255
    cv2.normalize(roiHist, roiHist, 0, 255, cv2.NORM_MINMAX)
    dst = cv2.calcBackProject([hsvTarImg], [0, 1], roiHist, [0, 180, 0, 256], 1)

    ### Now convolute with circular disc
    ### 使用卷積把分散的點連在一起
    disc = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (9, 9))
    dst = cv2.filter2D(dst, -1, disc)
    ### threshold and binary AND
    ret, thresh = cv2.threshold(dst, 50, 255, 0)
    kernel = np.ones((3, 3),np.uint8)
    thresh = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, kernel)
    thresh = cv2.morphologyEx(thresh, cv2.MORPH_CLOSE, kernel)


    
    ###################################################
    pts = get_max_area_box(thresh)  # 左下順時針順序
    ####### Segmentation 可視化測試 (for testting only)
    thresh = cv2.merge((thresh, thresh, thresh))
    res = cv2.bitwise_and(tarImg, thresh)
    # ShowImg('BinImg', thresh)
    res = np.hstack((tarImg, thresh, res))
    ####### 畫框可視測試 (for testting only) 
    testImg = tarImg.copy()
    cv2.rectangle(testImg, (pts[0][0], pts[0][1]), (pts[-2][0], pts[-2][1]),(255, 0, 0), 2)
    # ShowStackImgs('testImg', [res, testImg])
    return pts, thresh