import numpy as np
import cv2

def show_img(strID, img, size=(648, 486)):
    reImg = cv2.resize(img, size, interpolation=cv2.INTER_AREA)
    # cv2.imwrite(strID+'.jpg', reImg)
    cv2.imshow(strID, reImg)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

def otsu(image):
    try:
        gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    except:
        gray_image = image
    ret, thresh = cv2.threshold(gray_image, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)

    return thresh

def enhance_contrast(image, alpha, beta):
    """
    對比度
    """
    result = np.clip(alpha * image + beta, 0, 255)
    return result.astype(np.uint8)

def adjust_saturation(image, saturation_scale):
    """
    飽和度
    """
    hsv_image = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
    hsv_image = np.float32(hsv_image)

    ### 調整飽和度
    hsv_image[:, :, 1] *= saturation_scale
    
    ### 防止值超出255，這將導致顏色失真
    hsv_image[:, :, 1] = np.clip(hsv_image[:, :, 1], 0, 255)
    
    hsv_image = np.uint8(hsv_image)
    result_image = cv2.cvtColor(hsv_image, cv2.COLOR_HSV2BGR)
    return result_image

def sharpen_image(image):
    """
    銳利度
    """
    sharpen_kernel = np.array([[-1, -1, -1],
                                [-1, 9, -1],
                                [-1, -1, -1]])
    
    ### 將銳化核應用於影像
    result_image = cv2.filter2D(image, -1, sharpen_kernel)
    result_image = cv2.GaussianBlur(result_image, (3, 3), 0)
    return result_image

def clahe_image(image):
    """
    直方圖均衡化
    """
    # hsvImg = cv2.cvtColor(image, cv2.COLOR_BGR2YCR_CB)
    try:
        gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    except:
        gray_image = image
    # gray_image = hsvImg[:,:,2]
    clahe = cv2.createCLAHE(clipLimit = 1)
    claheImg = clahe.apply(gray_image)
    claheImg = cv2.GaussianBlur(claheImg, (3, 3), 0)

    return claheImg

def kmeans_image(image, n_clusters = 2):
    """
    kmeans
    """
    ### 提取圖像數據並轉換形狀，以便每個像素具有三個顏色通道（R、G 和 B）
    pixel_data = image.reshape(-1, 1).astype(np.float32)

    ### 設置終止條件
    criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 100, 0.2)

    ### 應用 KMeans 算法
    _, labels, centers = cv2.kmeans(pixel_data, n_clusters, None, criteria, 10, cv2.KMEANS_RANDOM_CENTERS)

    ### 取代原始像素值為相應的聚類中心 (顏色)
    result = centers[labels.flatten()].reshape(image.shape).astype(np.uint8)

    return result

def find_max_diff_region(grayImg):
    """圖片微分取顏色最大變化區域

    Args:
        grayImg (gray): 輸入灰階影像 

    Returns:
        gradMagNorm (gray): 輸出微分過後影像
    """
    ### 使用 Sobel 算子計算 X 和 Y 方向的一階微分
    gradX = cv2.Sobel(grayImg, cv2.CV_64F, 1, 0, ksize=3)
    gradY = cv2.Sobel(grayImg, cv2.CV_64F, 0, 1, ksize=3)

    ### 計算梯度大小 (gradMag) 並正規化到 [0, 255] 區間
    gradMag = np.sqrt(gradX**2 + gradY**2)
    gradMagNorm = cv2.normalize(gradMag, None, 0, 255, cv2.NORM_MINMAX, dtype=cv2.CV_8U)

    return gradMagNorm

def count_pixels_inside_polygon(image, points):
    """計算多邊形範圍內各顏色面積

    Args:
        image (gray): 輸入影像
        points (list): 多邊形座標

    Returns:
        whitePixels (int): 白色區域面積
        blackPixels (int): 黑色區域面積
    """
    # 創建一個全零的圖像(mask)與原圖像大小相同
    mask = np.zeros(image.shape, dtype=np.uint8)

    # 將把多邊形區域填充為白色 (255)
    cv2.fillConvexPoly(mask, points, 255)

    # 將原始圖像和mask進行位元且運算，得到新圖像
    maskedImage = cv2.bitwise_and(image, mask)

    # 計算白色和黑色像素數
    whitePixels = np.sum(maskedImage == 255)
    blackPixels = np.sum(maskedImage == 0) - np.sum(mask == 0)

    return whitePixels, blackPixels

def process_image(img, kernel_size):
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, kernel_size)
    img_morph = cv2.morphologyEx(img, cv2.MORPH_OPEN, kernel)
    otsu_img = otsu(img_morph)
    return otsu_img