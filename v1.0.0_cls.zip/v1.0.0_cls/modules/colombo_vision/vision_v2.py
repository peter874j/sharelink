import cv2 as cv
import numpy as np
import statistics
from ..peter_methods.ImageProcess import *
from ..peter_methods.CornerProcess import get_corner, trans_form_coords, get_board_distances, get_linear_equation_by_points, find_intersection
from ..peter_methods.HistSegment import get_roi_img, get_board_coords

from typing import Tuple
from ..models.ModuleCreator import RegionCreator
from ..models.ModuleCreator import ModelCreator
from ..colombo_vision.enum import *

class VisionV2:
    def __init__(self, task: str) -> None:
        self.__task = task

        self.__region_creator = RegionCreator()
        self.__model_creator = ModelCreator()
        self.__region_type = []
        self.__regions = []        
        self.__enhance_value = 50

    def setup_config(self, config):
        self.__region_num = {TaskType.POSITIONING.value: 4,
                             TaskType.CLASSIFICATION.value: 1}
        self.__region_type = [i for i in config[self.__task]]
        self.__regions = [self.__region_creator.set_module(region_name)(tuple(config[self.__task][region_name]["xy"]), tuple(config[self.__task][region_name]["wh"]))
                          for region_name in self.__region_type]
        self.__models = [self.__model_creator.set_module(model)() for model in config["model"]]

        self.__crop_area = config["image"]["crop_area"]
        self.__saturation_scale = config["image"]["saturation_scale"]
        self.__alpha = config["image"]["alpha"]
        self.__beta = config["image"]["beta"]
        self.__kernel_size = config["image"]["kernel_size"]
        self.__roi = config["image"]["roi"]

        self.__cls_crop_value = config["cls"]["crop_value"]
        self.__cls_alpha = config["cls"]["alpha"]
        self.__cls_beta = config["cls"]["beta"]
        self.__cls_exposure_gray = config["cls"]["exposure_gray"]
        self.__cls_exposure_area = config["cls"]["exposure_area"]
        self.__cls_vh_diff = config["cls"]["vh_diff"]
        self.__cls_vh_length = config["cls"]["vh_length"]
        self.__cls_wb_ratio = config["cls"]["wb_ratio"]

    def find_corners(self, img: np.array) -> Tuple[bool, dict]:
        # Peter
        cropImgs = [region.get_region(img) for region in self.__regions]
        roiImgs = get_roi_img(cropImgs, self.__crop_area)
        ### histogram back prejection
        _, thresh = get_board_coords(roiImgs, img)

        cropImgBin0 = thresh[self.__regions[0].left_top[1]:self.__regions[3].left_top[1] + self.__regions[3].h,
                             self.__regions[0].left_top[0]:self.__regions[3].left_top[0] + self.__regions[3].w]
        cropImgBin0 = cv2.cvtColor(cropImgBin0, cv2.COLOR_BGR2GRAY)
        cropImgBin0 = 255 - cropImgBin0

        # W.Y.Lee
        cropImg = img[self.__regions[0].left_top[1]:self.__regions[3].left_top[1] + self.__regions[3].h,
                      self.__regions[0].left_top[0]:self.__regions[3].left_top[0] + self.__regions[3].w]
        sharpenImg = sharpen_image(cropImg)
        adjustImg = adjust_saturation(sharpenImg, self.__saturation_scale)
        enhanceImg = enhance_contrast(adjustImg, self.__alpha, self.__beta)
        yuvImg = cv2.cvtColor(enhanceImg, cv2.COLOR_BGR2YUV)
        grayu = yuvImg[:,:,1]
        grayv = 255 - yuvImg[:,:,2]
        gray = clahe_image(grayv if grayv.std() > grayu.std() else grayu)
        otsuImg = otsu(gray)
        kernel = np.ones((self.__kernel_size,self.__kernel_size), np.uint8)
        otsuImg = cv2.morphologyEx(otsuImg, cv2.MORPH_CLOSE, kernel)
        otsuImg = cv2.morphologyEx(otsuImg, cv2.MORPH_OPEN, kernel)
        cropImgBin = otsuImg
        cropImgBin[cropImgBin0 == 0] = 0

        cropImgBin0[self.__roi[1]:self.__roi[3], self.__roi[0]:self.__roi[2]] = 0
        cropImgBin[self.__roi[1]:self.__roi[3], self.__roi[0]:self.__roi[2]] = 0
        cropImgOrig = cropImg.copy()
    
        corners = get_corner(cropImg, cropImgBin)
        if corners == None:
            corners = get_corner(cropImgOrig, cropImgBin0)
        
        corners = [trans_form_coords(corner, self.__regions[0].left_top) for corner in corners]
        result = img.copy()
        for corner in corners:
            cv2.circle(result, corner, 6, (0, 0, 255), -1)

        regions = {}
        for i, region in enumerate(self.__regions):
            regions[region.type] = {"img": self.__regions[i].get_region(result), "corner": corners[i]}

        return True, regions

    def top_layer_class(self, img: np.array) -> Tuple[bool, dict]:
        (h, w) = img.shape[:2]
        cropImg = img[(h // 2) - self.__cls_crop_value:(h // 2) + self.__cls_crop_value, 
                      (w // 2) - self.__cls_crop_value:(w // 2) + self.__cls_crop_value]
        hsvImg = cv2.cvtColor(cropImg, cv2.COLOR_BGR2HSV)
        channelVImg = hsvImg[:, :, 2] #V通道
        channelSImg = hsvImg[:, :, 1] #S通道
        crossMask = np.zeros_like(cropImg)
        exposureMask = np.zeros_like(cropImg)
        exposureMask = cv2.cvtColor(exposureMask, cv2.COLOR_BGR2GRAY)        
        channelVImg = cv2.fastNlMeansDenoising(channelVImg, h = 10, templateWindowSize = 7, searchWindowSize = 21)
        channelVImg = enhance_contrast(channelVImg, self.__cls_alpha, self.__cls_beta)
        maxDiffRegionImg = find_max_diff_region(channelVImg)
        otsuImgH = process_image(maxDiffRegionImg, (1, 25))
        otsuImgV = process_image(maxDiffRegionImg, (25, 1))

        channelSImg = cv2.fastNlMeansDenoising(channelSImg, h = 10, templateWindowSize = 7, searchWindowSize = 21)
        exposureMask[channelSImg < self.__cls_exposure_gray] = 255
        contours, _ = cv2.findContours(exposureMask, cv2.RETR_LIST, cv2.CHAIN_APPROX_NONE)
        exposureFeat = False
        if len(contours) > self.__cls_exposure_area:
            maxContour = max(contours, key=cv2.contourArea)
            cv2.drawContours(exposureMask, [maxContour], -1, (255, 255, 255), -1)
            exposureFeat = True

        topPoints, bottomPoints, VDist = get_board_distances(otsuImgV, mode = 'V', clsMode = True)
        leftPoints, rightPoints, HDist = get_board_distances(otsuImgH, mode = 'H', clsMode = True)
        lineFeat = False
        if VDist and HDist:          
            slopeT, interceptT, slopeB, interceptB = get_linear_equation_by_points(crossMask, topPoints, bottomPoints, statistics.mode(VDist), mode = 'V')
            slopeL, interceptL, slopeR, interceptR = get_linear_equation_by_points(crossMask, leftPoints, rightPoints, statistics.mode(HDist), mode = 'H')
            if None not in [slopeT, interceptT, slopeB, interceptB, slopeL, interceptL, slopeR, interceptR]:
                lineFeat = True

        crossFeat = False
        if lineFeat:
            if abs(statistics.mode(VDist) - statistics.mode(HDist)) < self.__cls_vh_diff and statistics.mode(VDist) > self.__cls_vh_length and statistics.mode(HDist) > self.__cls_vh_length:
                lLBoardPts = find_intersection(slopeT, interceptT, slopeL, interceptL)
                uLBoardPts = find_intersection(slopeB, interceptB, slopeL, interceptL)
                uRBoardPts = find_intersection(slopeB, interceptB, slopeR, interceptR)
                lRBoardPts = find_intersection(slopeT, interceptT, slopeR, interceptR)
                points = np.array([lLBoardPts, uLBoardPts, uRBoardPts, lRBoardPts], dtype=np.int32)
                crossFeat = True

        if crossFeat and exposureFeat:
            whitePixels, blackPixels = count_pixels_inside_polygon(exposureMask, points)
            crossMask[exposureMask == 255] = 255
            clsResult = ('Top Layer : Tray' if whitePixels == 0 else
                    'Top Layer : Lid' if blackPixels == 0 or (whitePixels / blackPixels) * 100 > self.__cls_wb_ratio else
                    'Top Layer : Tray')

        if not exposureFeat or not lineFeat or not crossFeat:
            crossMask = exposureMask
            clsResult = ('Top Layer : Circuit Board')
        cv2.putText(img, clsResult, (100, 150), cv2.FONT_HERSHEY_SIMPLEX, 3, (0, 255, 255), 3, cv2.LINE_AA)

    def cal_center(self, img: np.array, corners: np.array) -> Tuple[np.array, np.array]:
        """
        Get four corners on pannel and calculate pannel center.
        
        """
        corners = np.asarray(corners, dtype=np.float32)

        for model in self.__models:
            H, corners_transfromed = model.get_perspective_transform(corners)
            # Get center
            center = np.int16(corners_transfromed[4])
            # Get img in HSV model
            hsv = cv.cvtColor(img, cv.COLOR_BGR2HSV_FULL)
            # Get hue in center
            hue = hsv[(center[1], center[0])][0]
            if model.is_model(hue):
                return H, corners_transfromed, model
        print(f"Unexpected Hue: {hue}")

        return H, corners_transfromed, self.__model_creator.set_module(-1)()

    def cal_angle(self, p1: tuple, p2: tuple) -> float:
        vector = np.asarray(p2) - np.asarray(p1)
        theta =  np.arctan(vector[1] / vector[0])
        return theta

    def build_camera_view(self, img: np.array) -> np.array:
        """
        Enhance view in camera workspace.

        """
        regions = []
        for region in self.__regions:
            regions.append({"img": region.get_region(img),
                            "left_top": region.left_top})
        img = np.where((255 - img) < self.__enhance_value, 255, img + self.__enhance_value)
        for region in regions:
            img = self.add_image(img, region["img"], region["left_top"])
        return img

    def add_image(self, img1: np.array, img2: np.array, xy: tuple=(0, 0)) -> np.array:
        """
        Mix two image into an image, size of img1 should be larger than img2.
        :xy -> left-top corner
        
        """
        img1[xy[1]:xy[1] + img2.shape[0], xy[0]:xy[0] + img2.shape[1]] = img2
        return img1

    def build_corner_block(self, regions: np.array) -> np.array:
        max_w = 0
        padding_regions = []
        for region in regions:
            if region.shape[1] > max_w:
                max_w = region.shape[1]
        for region in regions:
            padding_regions.append(cv.copyMakeBorder(region, 0, 10, 0, max_w - region.shape[1], cv.BORDER_CONSTANT, value=[50, 50, 50]))
        corner_block = cv.vconcat(padding_regions)
        return corner_block

    @property
    def regions(self):
        return self.__regions
    
    @property
    def task(self):
        return self.__task
    
    @property
    def region_num(self):
        return self.__region_num[self.__task]