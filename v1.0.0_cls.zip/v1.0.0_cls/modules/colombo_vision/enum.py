from enum import Enum

class TaskCode(Enum):
    SUCCESS = 0
    TAKE_PIC_ERROR = 1
    DETECT_CENTER_ERROR = 2
    CLASSIFY_AREA_ERROR = 3
    MOVE_ROBOT_ERROR = 4
    UNEXPECTED_ERROR = 5

class TaskType(Enum):
    POSITIONING = "positioning"
    CLASSIFICATION = "classification"

class ModelType(Enum):
    SPACER_WHITE_630x530x20 = 0
    SPACER_WHITE_511x455x20 = 1
    SPACER_BLUE_652x571x20 = 2
    SPACER_YELLOW_415x510x01 = 3
    PANEL_610x511x12 = 4
    PANEL_511x415x005 = 5
    DUMMY_610x511x01 = 6