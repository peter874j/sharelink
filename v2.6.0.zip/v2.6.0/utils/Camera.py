import cv2
from pypylon import pylon
import threading
import os
from utils.Detection import flaw_detect
import time
# from packages.Relay import RelayCls  ###OA電腦需關閉
from datetime import datetime
from utils.GetCfg import CamPramCfg, ServerPramCfg


class CamMutual:
    # relay         = RelayCls()  ###OA電腦需關閉
    # usbPort        = relay.get_usb_port()  ###OA電腦需關閉
    usbPort        = None
    relayIsRun     = False
    timeNow        = datetime.now().strftime("%H_%M_%S")
    batch          = 0  ###加總為4為一輪
    severParmDict  = ServerPramCfg().cfg_load()
    camParmDict    = CamPramCfg().cfg_load()

class Camera:
    def __init__(self, devices=None, tlFactory=None, converter=None, cameras=None, device=None):
        self.isrunning = True
        self.device = device
        self.devices = devices
        self.tlFactory = tlFactory
        self.converter = converter
        self.cameras = cameras
        self.create_device()
        self.stratTime = time.time()

    def get_key(self, dict, value):
        return[k for k, v in dict.items() if v == value]

    def create_device(self):
        # Create and attach all Pylon Devices.
        for i, cam in enumerate(self.cameras):
            if i == self.device:
                cam.Attach(self.tlFactory.CreateDevice(self.devices[i]))
                cam.Open()
                try:
                    self.deviceNumber = cam.DeviceSerialNumber()
                    device = ','.join(self.get_key(CamMutual.camParmDict, self.deviceNumber)).replace('_deviceNumber', '')
                    cam.Width.SetValue(CamMutual.severParmDict['width'])
                    cam.Height.SetValue(CamMutual.severParmDict['height'])
                    cam.ExposureTime.SetValue(CamMutual.camParmDict["{}_exposuretime".format(device)])
                    cam.Gain.SetValue(CamMutual.camParmDict["{}_gain".format(device)])
                    cam.Gamma.SetValue(CamMutual.camParmDict["{}_damma".format(device)])
                    cam.BlackLevel.SetValue(CamMutual.camParmDict["{}_BlackLevel".format(device)])
                    cam.ReverseX.SetValue(CamMutual.camParmDict["{}_ReverseX".format(device)])
                    cam.ReverseY.SetValue(CamMutual.camParmDict["{}_ReverseY".format(device)])
                    self.deviceNumber = cam.DeviceSerialNumber()
                except:
                    print('Create device error')
                self.cameras[i].StartGrabbing(pylon.GrabStrategy_LatestImageOnly)
                

    def run(self):
        self.thread = threading.Thread(target=self.updateVideo, args=([self.device]))
        self.thread.start()

    def update(self, device):
        while True:
            while self.cameras[device].IsGrabbing() and self.isrunning:
                try:
                    grabResult = self.cameras[device].RetrieveResult(5000, pylon.TimeoutHandling_ThrowException)
                    if grabResult.GrabSucceeded():
                        self.status = True
                        image = self.converter.Convert(grabResult)
                        self.frame = image.GetArray()

                    grabResult.Release()

                except:
                    try:
                        self.create_device()
                    except:
                        cv2.destroyAllWindows()
                        print("Waiting camera[{}] open...".format(device + 1))

            try:
                self.create_device()
            except:
                print("Waiting create device[{}]...".format(device + 1))

    def updateVideo(self, device):
        dataPath = r'./data'
        dataTime = '14_56_41'
        if device == 0:
            cap = cv2.VideoCapture(os.path.join(dataPath, "{}_cam3.avi".format(dataTime)))
        if device == 1:
            cap = cv2.VideoCapture(os.path.join(dataPath, "{}_cam0.avi".format(dataTime)))
        if device == 2:
            cap = cv2.VideoCapture(os.path.join(dataPath, "{}_cam1.avi".format(dataTime)))
        if device == 3:
            cap = cv2.VideoCapture(os.path.join(dataPath, "{}_cam2.avi".format(dataTime)))
        n = 0
        while cap.isOpened() and self.isrunning:
            n += 1
            if n == 1:  # read every 4th frame
                (self.status, frame) = cap.read()
                if self.status:
                    self.frame = frame
                n = 0
            time.sleep(0.001)

    def stop(self):
        self.isrunning = False

    def get_now_time(self):
        if CamMutual.batch >= 4:
            CamMutual.timeNow = datetime.now()
            CamMutual.batch = 0
            CamMutual.relayIsRun = False
            print('round end')
        CamMutual.batch += 1

    def get_frame(self, stream=True ,flag_printer=0):
        ###繼電器監控
        # CamMutual.usbPort = CamMutual.relay.get_usb_port() ###OA電腦需關閉
        if CamMutual.usbPort == None:
            flag_printer = 1

        endTime = time.time()
        if stream:
            if self.status:
                if endTime - self.stratTime > CamMutual.severParmDict['freq']:
                    self.stratTime = time.time()
                    self.get_now_time()
                    print(CamMutual.batch, CamMutual.timeNow)
                    result, status = flaw_detect(self.frame, self.device, CamMutual.timeNow, CamMutual.severParmDict)
                    if status =='NG' and not CamMutual.relayIsRun and flag_printer == 0:
                        CamMutual.relayIsRun = True
                        # CamMutual.relay.run(CamMutual.severParmDict['printerruntime'])  ###OA電腦需關閉
                else:
                    result = self.frame
                    
                return result, CamMutual.usbPort 
            else:
                print("no image...")
                return None, None
        else:
            print("gg")
            pass


if __name__ == "__main__":
    os.environ["PYLON_CAMEMU"] = "3"
    maxCamerasToUse = 4
