import os
import cv2
import numpy as np
from datetime import datetime
from pathlib import Path
from utils.FilterProcess import FilterBackground, FilterRule
from utils.FileManager import FileManagement
import threading

def remove_file(parmDict, pathFolder):
    '''
    定時定量刪除
    '''
    FM = FileManagement()
    FM.auto_remove_by_date(os.path.join(os.getcwd(), pathFolder), parmDict['maxdays'])
    FM.auto_remove_by_size(os.path.join(os.getcwd(), pathFolder), parmDict['maxmbsize'])

def remove_file_run(parmDict, pathFolder):
    '''
    remove_file執行續
    '''
    thread = threading.Thread(target = remove_file, args=([parmDict, pathFolder]))
    thread.start()

def save_file(savePath, device, isNG, timeNow, imageOrgi, result):
    '''
    檢測結果並輸出
    '''
    if isNG:
        status = "NG"
        cv2.imwrite(os.path.join(savePath, status, 'Orig', '{}_cam{}.jpg'.format(timeNow.strftime("%H_%M_%S"), device)), imageOrgi)
    else:
        status = "OK"
    cv2.imwrite(os.path.join(savePath, status, '{}_cam{}.jpg'.format(timeNow.strftime("%H_%M_%S"), device)), result)

def save_file_run(savePath, device, isNG, timeNow, imageOrgi, result):
    '''
    save_file執行續
    '''
    thread = threading.Thread(target = save_file, args=([savePath, device, isNG, timeNow, imageOrgi, result]))
    thread.start()    

def save_path(timeNow, parmDict):
    pathFolder  = "log"
    savePath = Path(r".\\").joinpath(pathFolder, timeNow.strftime("%Y%m%d"))
    Path(os.path.join(savePath, 'NG')).mkdir(parents=True, exist_ok=True)
    Path(os.path.join(savePath, 'OK')).mkdir(parents=True, exist_ok=True)
    Path(os.path.join(savePath, 'NG', 'Orig')).mkdir(parents=True, exist_ok=True)
    remove_file_run(parmDict, pathFolder)
    return savePath

def flaw_detect(image, device, timeNow, parmDict):
    savePath = save_path(timeNow, parmDict)
    imgOrgi = image.copy()
    filterRule = FilterRule(parmDict)
    filterBackground = FilterBackground(image)
    image, points, points_pair= filterBackground.background(parmDict)

    ### 圖像轉灰階
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    imgResult = image.copy() 

    ###值方圖均衡化
    clahe = cv2.createCLAHE(clipLimit=1)
    clahe_img = clahe.apply(gray)
    clahe_img = cv2.medianBlur(clahe_img, parmDict['blurvalue'])

    ###提取輪廓
    thresh = cv2.adaptiveThreshold(clahe_img, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, parmDict['binaryroil'], parmDict['binaryvaluel'])
    thresh2 = cv2.adaptiveThreshold(clahe_img, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, parmDict['binaryroih'], parmDict['binaryvalueh'])
    thresh[thresh2==0] = 0

    ###於板內邊緣塗白邊(確保最大外接矩形正確)
    cv2.polylines(thresh, [points_pair], isClosed= True, color=(255,255,255), thickness=11)

    ###於板外面積塗白(確保黑色區域皆為Defect)
    cv2.fillPoly(thresh, [points], color=255)

    ###尋找所有矩形
    contours, _ = cv2.findContours(thresh, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    max_contour = max(contours, key=cv2.contourArea)

    isNG = False
    for contour in contours:
        ###假如為最大外接矩形不做任何動作
        if np.array_equal(contour, max_contour):
            pass
        else:
            diameter = filterRule.find_max_diameter(contour)
            avgPixValue = filterRule.find_gray_value(gray, contour)
            resultPet = (abs(avgPixValue - 255) / 255) * 100
            if resultPet > parmDict['garypct'] and diameter > parmDict['nglength']:
                isNG = True
                cv2.drawContours(imgResult, [contour], 0, (0, 0, 255), 1)

    ###檢測結果並輸出
    save_file_run(savePath, device, isNG, timeNow, imgOrgi, imgResult)

if __name__ == "__main__":
    folder_path = './data/1_NG'

    # 遍历文件夹中的所有文件
    for filename in os.listdir(folder_path):
        # 拼接文件路径
        name, extension = os.path.splitext(filename)
        try:
            timeNow = datetime.now()
            flaw_detect(folder_path, filename, timeNow)
        except:
            print(name)
