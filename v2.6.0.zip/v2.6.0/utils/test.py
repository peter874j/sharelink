import os
import shutil

if __name__ == "__main__":
    # folderPath = './data/NG'
    folderPath = 'D:/UserShare/YOLO/WYLee/gitlab/cgpc-door-panel-defect-detection/data/過殺/髒污'
    # sourcePath = 'D:/UserShare/YOLO/WYLee/gitlab/Magellan/log/20230606_OK/NG/Orig'
    sourcePath = 'D:/UserShare/YOLO/WYLee/gitlab/cgpc-door-panel-defect-detection/log/第一台驗證(所有瑕疵)/程式檢所有NG/NG'
    # targetPath = 'D:/UserShare/YOLO/WYLee/gitlab/Magellan/log/20230606_OK/NG/Bmp'
    targetPath = 'D:/UserShare/YOLO/WYLee/gitlab/cgpc-door-panel-defect-detection/data/result'    
    # 遍历文件夹中的所有文件
    for fileName in os.listdir(folderPath):
        # 拼接文件路径
        name, extension = os.path.splitext(fileName)
        for fileDefectName in os.listdir(sourcePath):
            defectName, defectExtension = os.path.splitext(fileDefectName)
            if name in defectName:
                try:
                    if defectName == name:
                        shutil.copyfile(os.path.join(sourcePath, fileDefectName), os.path.join(targetPath, '{}_defect.jpg'.format(name)))
                    else:
                        shutil.copyfile(os.path.join(sourcePath, fileDefectName), os.path.join(targetPath, fileDefectName))
                except:
                    print('is Orgi Path')
        # print(name, extension)


# if __name__ == "__main__":
#     origPath = 'D:/UserShare/YOLO/WYLee/gitlab/Magellan/data/OK'
#     sourcePath = 'D:/UserShare/YOLO/WYLee/gitlab/Magellan/data/mask'
#     targetPath = 'D:/UserShare/YOLO/WYLee/gitlab/Magellan/data/maskpng'
#     # 遍历文件夹中的所有文件
#     for fileName in os.listdir(sourcePath):
#         # 拼接文件路径
#         name, extension = os.path.splitext(fileName)
#         shutil.copyfile(os.path.join(sourcePath, '{}.jpg'.format(name)), os.path.join(targetPath, '{}.png'.format(name.replace('_mask', ''))))
#         print(name, extension)