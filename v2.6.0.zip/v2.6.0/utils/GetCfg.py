import configparser

class ServerPramCfg:
    def __init__(self):
        self.config = configparser.ConfigParser()
        self.config.read(r"./data/cfg/Service.cfg")
        self.serverPramDict = {}

    def cfg_load(self):
        for i in self.config.items('Server'):
            try:
                self.serverPramDict[i[0]] = int(i[1])
            except:
                self.serverPramDict[i[0]] = str(i[1])
        return self.serverPramDict

class CamPramCfg:
    def __init__(self):
        self.config = configparser.ConfigParser()
        self.config.read(r"./data/cfg/CamSet.cfg")
        self.deviceList  = ["Top_cam1", "Top_cam2", "Btm_cam1", "Btm_cam2"]
        self.camPramDict = {}

    def cfg_load(self):
        for cam in self.deviceList:
            self.camPramDict["{}_deviceNumber".format(cam)]= self.config.get(cam, "deviceNumber")
            self.camPramDict["{}_exposuretime".format(cam)]= self.config.getint(cam, "exposuretime")
            self.camPramDict["{}_gain".format(cam)]= self.config.getfloat(cam, "gain")
            self.camPramDict["{}_damma".format(cam)]= self.config.getfloat(cam, "damma")
            self.camPramDict["{}_BlackLevel".format(cam)]= self.config.getfloat(cam, "BlackLevel")
            self.camPramDict["{}_ReverseX".format(cam)]= self.config.getboolean(cam, "ReverseX")
            self.camPramDict["{}_ReverseY".format(cam)]= self.config.getboolean(cam, "ReverseY")
        return self.camPramDict
