import serial
import serial.tools.list_ports
import threading
import time

class RelayCls:
    def __init__(self) -> None:
        self.START_ID = 0xA0
        self.ON_ID = 0x01
        self.OFF_ID = 0x00

    def get_usb_port(self):
        ports = serial.tools.list_ports.comports()
        for port, desc, _ in sorted(ports):
            if 'USB-SERIAL CH340' in desc:
                self.relatPort = port
            else:
                self.relatPort = None
        return self.relatPort

    def Get_Cmd_Prototype(self):
        data = bytearray()
        data.append(self.START_ID)
        data.append(0x00)  # Switch Number
        data.append(0x00)  # Action ON or OFF
        return data

    def Send_Data(self, port, data):
        try:
            ser = serial.Serial(port)
            ser.write(data)
            ser.close()
            return True
        except:
            return False

    def Get_ON_Cmd(self, SWITCH_NUM):
        data = self.Get_Cmd_Prototype()
        data[1] = SWITCH_NUM
        data[2] = self.ON_ID
        data.append(data[0] + data[1] + data[2])
        return data

    def Get_OFF_Cmd(self, SWITCH_NUM):
        data = self.Get_Cmd_Prototype()
        data[1] = SWITCH_NUM
        data[2] = self.OFF_ID
        data.append(data[0] + data[1] + data[2])
        return data

    def Turn_Relay_ON(self):
        cmd = self.Get_ON_Cmd(1)
        status = self.Send_Data(port=self.relatPort, data=cmd)
        return status

    def Turn_Relay_OFF(self):
        cmd = self.Get_OFF_Cmd(1)
        status = self.Send_Data(port=self.relatPort, data=cmd)
        return status

    def run(self, runTime):
        self.thread = threading.Thread(target=self.relay_run, args=([runTime]))
        self.thread.start()

    def relay_run(self, runRime):
        self.Turn_Relay_ON()
        time.sleep(int(runRime))
        self.Turn_Relay_OFF()

if __name__ == "__main__":
    relay = RelayCls()
    print(relay.Turn_Relay_ON())
    time.sleep(1)
    print(relay.Turn_Relay_OFF())
    time.sleep(1)
    print(relay.Turn_Relay_ON())
    time.sleep(1)
    print(relay.Turn_Relay_OFF())